function promoBanner() {
    var e, r = document.querySelectorAll(".premiumPromoBannerWrapper"),
        n = SessionStorageManager.getInstance();
    !r.length || "" == smallImageFg && "" == smallImageBg || ((e = document.querySelector(".premiumPromoBannerClose")) && e.addEventListener("click", function(e) {
        e.preventDefault ? e.preventDefault() : e.returnValue = !1, "persistant" == persistantMode ? n.set("promoBannerPersistant", "1", 1) : n.set("premiumPromoBanner" + promobannerId, "1", 1), this.closest(".premiumPromoBannerWrapper").style.display = "none"
    }), "persistant" == persistantMode ? n.get("promoBannerPersistant") || (r[0].style.display = "block") : n.get("premiumPromoBanner" + promobannerId) || (r[0].style.display = "block"), MG_Utils.addEventHandler(document.querySelector(".promoBannerClassAnchor"), "click", function() {}))
}
MG_Utils.domReady(promoBanner);