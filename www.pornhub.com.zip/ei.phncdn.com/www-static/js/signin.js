function userSignUpClog(e, t, i, n, s, o) {
    var s = s ? "&origin_item_id=" + s : "",
        a = 1 < n.length ? "&origin_url=" + encodeURIComponent(n) : "",
        n = 1 < n.length ? "&origin=" + i : "",
        i = "&origin_item_variation=" + o;
    let l = "";
    void 0 !== page_params["geo-localization"] && "all" !== page_params["geo-localization"] && (l = "&geo-localization=" + page_params["geo-localization"]);
    var r = "";
    if ("undefined" != typeof page_params && page_params.subdomain && "signup-open" == t) switch (page_params.subdomain) {
        case "es":
            r = "&geo-localization=spanish";
            break;
        case "jp":
            r = "&geo-location=japan";
            break;
        default:
            r = ""
    }
    MG_Utils.ajaxCall({
        url: e + "/_i?type=event&event=" + t + n + a + s + i + l + r,
        type: "POST"
    })
}
var extendedPropsForModal = {
        signInUtilModal: null,
        config: TOP_BODY,
        show: function(e) {
            e = void 0 !== e ? e : {}, "undefined" != typeof event && event.preventDefault(), this.options = e;
            var t, i, n = document.getElementById("signinModal");
            if (navigator.userAgent && navigator.userAgent.match(/PLAYSTATION/)) return document.location.assign("http://" + location.hostname + "/login"), !1;
            "block" === n.style.display && 1 != this.config.shorties || (i = !!(t = document.getElementById("rightMenu")) && t.querySelector(".closeHamMenu"), t && MG_Utils.hasClass(t, "active") && i && i.click(), this._openModal(e, n), "function" == typeof appendedTasteProfile && appendedTasteProfile("js-tasteProfileLoginModal"))
        },
        _openModal: function(s, e) {
            e && (this.signInUtilModal = new MG_Modal({
                content: e,
                className: "loginModal",
                afterunload: (t, e) => {
                    if (MG_Utils.hasClass(e, "updatedModal")) {
                        const i = e => {
                            document.removeEventListener("click", i);
                            e = e.target === t ? "outside_modal_window" : "button-close-x";
                            userSignUpClog(currentDomain, "signup-aborted", originPart, originUrl, e, newModal)
                        };
                        document.addEventListener("click", i)
                    }
                }
            }), this.signInUtilModal) && (this.newInstance = !1, this.signInUtilModal.openModal((e, t) => {
                var i, n;
                this.container = t, this._toggleModalContent(this.container, s), s.subscribe && (t = this.container.querySelector(".js-loginForm"), (i = document.createElement("input")).type = "hidden", i.name = "subscribe", i.value = 1, t.appendChild(i)), s.shortiesInputVideoId && (t = this.container.querySelector(".js-loginForm"), i = document.createElement("input"), n = document.createElement("input"), i.type = "hidden", i.name = "videoId", i.value = s.shortiesInputVideoId, t.appendChild(i), t.appendChild(n)), this.init(), this.showCaptcha && (this._initializeCaptcha(), this.toggleButtonDisable(!0)), this.newInstance = !0
            }), e = document.querySelectorAll(".js_closeModal"), MG_Utils.addEventHandler(e, "click", () => {
                this.signInUtilModal.closeModal(), this.recaptchaCompleted = !1, this.container = null
            }), this.newInstance || this._toggleModalContent(this.container, s))
        },
        _toggleModalContent: function(e, t) {
            var i = e.querySelector(".signInWrap"),
                n = e.querySelector(".signUpWrap");
            i && n && ("signIn" === t.step || void 0 === t.step ? (this._resetForms(i), MG_Utils.addClass(n, "displayNone"), MG_Utils.removeClass(i, "displayNone"), "undefined" != typeof phCustomEvent && phCustomEvent.dispatch("initSignUp", !1)) : "signUp" !== t.step && "signUpLikedVideo" !== t.step && "signUpVideoLikedWatchPage" !== t.step || (window.dataLayer.push({
                event: "signup_impression",
                location: "signUpLikedVideo" === t.step ? "liked_videos_page_cta" : "signUpVideoLikedWatchPage" === t.step ? "liked_videos_snackbar" : "undefined"
            }), MG_Utils.removeClass(n, "displayNone"), MG_Utils.addClass(i, "displayNone"), MG_Utils.addClass(e, "updatedModal"), "undefined" != typeof phCustomEvent && phCustomEvent.dispatch("initSignUp", !0)))
        },
        _resetForms: function(e) {
            var t, i, n = e.getAttribute("data-step");
            n && "signIn" === n && (n = e.querySelector("form"), t = e.querySelector("#signinSubmit"), i = e.querySelector(".signinError"), e = e.querySelectorAll("input"), n && n.reset(), t && t.setAttribute("disabled", "disabled"), t && MG_Utils.addClass(t, "disabled"), e && MG_Utils.removeClassMultiple(e, "signin_error"), i) && (i.innerText = "")
        },
        _initializeCaptcha: function() {
            try {
                var e = this.container.querySelector(".g-recaptcha");
                null != typeof CaptachaComponents && e && CaptachaComponents.registerComponent(e, this.captchaAcknowledgement)
            } catch (e) {}
        },
        redirectFromResponse: function(e) {
            var t = this.container.querySelector("#signinLoggingin"),
                i = this.container.querySelector(".js-signinUsername"),
                n = this.container.querySelector(".js-signinPassword"),
                s = document.getElementsByClassName("ph-icon-error"),
                o = this.container.querySelector(".signinError");
            e.redirect ? (t.style.display = "block", o.style.display = "none", MG_Utils.removeClass(i, "signin_error"), MG_Utils.removeClass(n, "signin_error"), MG_Utils.addClassMultiple(s, "displayNone"), void 0 !== e.subscribe && 1 == e.subscribe ? document.querySelector(".subscribeButton button.login").setAttribute("data-login", "0") : this.options.callbackCustomRedirect && "function" == typeof this.options.callbackCustomRedirect ? this.options.callbackCustomRedirect(e) : document.location.assign(e.redirect)) : (o.style.display = "block", o.innerHTML = e.message, MG_Utils.addClass(i, "signin_error"), MG_Utils.addClass(n, "signin_error"), MG_Utils.removeClassMultiple(s, "displayNone"), this.toggleButtonDisable(!1))
        },
        callbackSuccess: function(i) {
            if ("0" == i.premium_redirect_cookie || i.forceRedirect) {
                if (i.showExpiredFreeTrial) return this.premiumModalFromResponse(i);
                this.redirectFromResponse(i)
            } else {
                var e = new Date,
                    e = premiumRedirectCookieURL + (0 < premiumRedirectCookieURL.indexOf("?") ? "&" : "?") + "timestamp=" + e.getTime();
                const t = new XMLHttpRequest;
                t.withCredentials = !0, t.open("GET", e, !0), t.onreadystatechange = function() {
                    var e, t;
                    4 === this.readyState && 200 <= this.status && this.status < 400 && (e = this.container.querySelector("#signinLoggingin"), t = this.container.querySelector(".signinError"), i.redirect ? (e.style.display = "", t.style.display = "none", document.location.assign(i.redirect)) : (t.style.display = "", t.innerHTML = i.message, this.toggleButtonDisable(!1)))
                }, t.send(), t = null
            }
        },
        loginAjaxSuccess: function(e) {
            var t;
            e.twoStepVerification ? (t = this.container.querySelector(".js-loginForm")) && (MG_Utils.addClass(t, "displayNone"), this.setupTwoStepVerification(e)) : e.requireCaptcha ? (this.showCaptcha = !0, jQuery(".js-loginForm .signinError").show().html(e.message), this.setupCaptacha()) : this.callbackSuccess(e)
        },
        initGoogleSso: function() {
            var e = document.getElementsByTagName("head")[0],
                t = document.createElement("script"),
                i = (t.type = "text/javascript", t.src = "https://accounts.google.com/gsi/client", e.appendChild(t), this);
            t.onload = function() {
                google.accounts.oauth2.initTokenClient({
                    client_id: gSSOClientId,
                    scope: "https://www.googleapis.com/auth/userinfo.email",
                    ux_mode: "popup",
                    callback: e => {
                        i.loginAjax(e.access_token, ".loginModal form.js-loginForm")
                    }
                }).requestAccessToken()
            }
        }
    },
    signinbox = Object.assign({}, Signinbox, extendedPropsForModal);
MG_Utils.domReady(function() {
    document.location.search.match(/showSigninBox=true/i) && null != document.getElementById("headerLoginLink") && signinbox.show();
    let e = document.getElementById("headerLoginLink"),
        i = document.querySelector(".profileOptions");
    e && e.addEventListener("click", function() {
        i && (MG_Utils.hasClass(i, "show") ? MG_Utils.removeClass(i, "show") : (MG_Utils.addClass(i, "show"), userSignUpClog(currentDomain, "user-menu", originPart, originUrl, clickedElement, newModal)))
    }), document.addEventListener("click", function(e) {
        var t = e.target;
        e && t && "headerLoginLink" !== t.id && !MG_Utils.hasClass(t, "selectMenu") && i && MG_Utils.removeClass(i, "show"), (MG_Utils.hasClass(t, "closeMTubes") || MG_Utils.hasClass(t, "isVisibleMTubes")) && "undefined" != typeof sessionStorage && null !== sessionStorage.getItem("notLoggedIn") && sessionStorage.removeItem("notLoggedIn")
    }), jQuery(document).on("click", "#ssoGoogleSigninButton", function() {
        signinbox.initGoogleSso()
    })
});