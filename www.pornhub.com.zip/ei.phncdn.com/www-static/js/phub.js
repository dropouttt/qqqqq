var certifyVideoModal, mainHubWelcomeModal, confirmPopUpModal = null,
    phubGenericFuncModule = {
        setCategoryLink: null,
        setCookie: function(e) {
            var t, a;
            "undefined" != typeof CookieHelper && !CookieHelper.canAdd(e.split("=")[0]) || (t = "undefined" != typeof COOKIE_DOMAIN ? ";domain=" + COOKIE_DOMAIN : "", (a = new Date).setTime(a.getTime() + 3e4), document.cookie = e + ";expires=" + a.toUTCString() + ";path=/" + t)
        },
        friendReqSubmit: function() {
            var s = document.querySelector("#preventClick"),
                i = s ? s.getAttribute("data-user-id") : "",
                e = document.querySelector("#friendRequestForm"),
                r = document.querySelector(".friend_" + i + " button"),
                l = r.children;
            MG_Utils.ajaxCall({
                url: e.getAttribute("action"),
                data: function(e) {
                    for (var t = document.querySelectorAll(e), a = {}, n = 0; n < t.length; n++) a[t[n].name] = 1e3 < t[n].value.length ? t[n].value.substring(0, 1e3) : t[n].value;
                    return a
                }('#friendRequestForm input:not([type="button"]), #friendRequestForm textarea'),
                type: "POST",
                dataType: "JSON",
                beforeSend: function() {
                    for (var e = 0; e < l.length; e++) MG_Utils.addClass(l[e], "visuallyHidden");
                    r.insertAdjacentHTML("beforeend", '<span class="spinner" />')
                },
                success: function(e) {
                    var t = document.querySelector(".friend_" + i),
                        a = r.querySelector(".spinner"),
                        n = document.querySelector(".subscribe_" + i);
                    "undefined" != typeof friendRequestModal && "SENT" === e.success && friendRequestModal.closeModal();
                    for (var o = 0; o < l.length; o++) MG_Utils.removeClass(l[o], "visuallyHidden");
                    a && r.removeChild(a), "SENT" == e.success ? (r.setAttribute("data-friends", 1), t && MG_Utils.removeClass(t, "removeFriend"), t && MG_Utils.removeClass(t, "add"), t && MG_Utils.addClass(t, "sent"), n && e.subscribed && (n.querySelector("button").setAttribute("data-subscribed", 1), MG_Utils.removeClass(n, "subscribe"), MG_Utils.addClass(n, "unsubscribe"), n.querySelector(".buttonLabel").textContent = "Subscribed"), s && 1 == s.getAttribute("data-refresh") && location.reload(), t && t.querySelector(".buttonLabel") && (t.querySelector(".buttonLabel").textContent = e.text_initial)) : alert(e.message)
                }
            })
        },
        sendSearchGAEvent: function(e) {
            var e = e && e.target && e.target.dataset ? e.target.dataset.ga : null,
                t = Math.random() <= .1;
            e && "function" == typeof ga && t && ga("send", "event", "related search", "click", e)
        },
        sendGAEvent: function(e, t, a) {
            var n = (n = getCookieAdvanced("gaProbabilityPercent")) ? parseInt(n) / 100 : a || 1,
                a = Math.random() <= n;
            e && t && "function" == typeof ga && a && ga("send", "event", e, "click", t)
        }
    };

function triggerSignInSignUpModal() {
    var e = "undefined" != typeof defaultSignUpModal && defaultSignUpModal ? "signUp" : "signIn";
    signinbox && signinbox.show({
        step: e
    })
}
var eventsModule = function() {
        function a(e) {
            var t;
            e.target && MG_Utils.hasClass(e.target, "pornstarsList") && (t = e.target.value) && (e.target.value = t.replace(/[\<\>|\[\]|\{\}|\(\)]/gi, ""))
        }

        function C(a) {
            var e;
            void 0 !== (confirmPopUpModal = void 0 !== confirmPopUpModal && !confirmPopUpModal && (Vue.customElement("confirm-modal", {
                computed: {
                    getButtonText: function() {
                        return modalTranslationText.okButton
                    }
                },
                template: '<div id="confirmModal" class="modalWrapper"><div class="modal-body"><div class="text"></div><button class="orangeButton js-okBtn" data-modal="info">{{getButtonText}}</button></div></div>'
            }), e = document.getElementById("confirmModal")) ? new MG_Modal({
                content: e,
                className: "infoModalContainer"
            }) : confirmPopUpModal) && confirmPopUpModal && confirmPopUpModal.openModal(function(e, t) {
                t = t.querySelectorAll(".text");
                t && (t[0].innerHTML = a)
            })
        }

        function y(e, t) {
            var a = document.querySelector("form input.intendedAction"),
                n = document.querySelector("form input.userId");
            a && n && (a.value = e, n.value = t.getAttribute("data-id"))
        }

        function b(e, t, a) {
            e.preventDefault();
            var s = void 0 !== t ? t : "BUTTON" === e.target.tagName ? e.target : e.target.parentElement,
                i = s.children,
                t = s.parentElement.getAttribute("data-button-id"),
                r = document.querySelectorAll("." + t),
                l = document.querySelectorAll("." + t + " button"),
                d = document.querySelectorAll("." + t + " .buttonLabel"),
                t = 0 == s.getAttribute("data-subscribed") ? s.getAttribute("data-subscribe-url") : s.getAttribute("data-unsubscribe-url"),
                n = s.getAttribute("data-login"),
                c = s.getAttribute("data-refresh"),
                o = 0 == s.getAttribute("data-subscribed") ? "By subscribing to this content partner you are also subscribing to all of their channels, would you like to continue?" : "By unsubscribing from this content partner you are also unsubscribing from all of their channels, would you like to continue?",
                u = s.getAttribute("data-content-partner"),
                m = s.getAttribute("data-is-pornhub"),
                p = s.getAttribute("data-hidden");
            1 == n ? (y("subscribe", s), n = "undefined" != typeof defaultSignUpModal && defaultSignUpModal ? "signUp" : "signIn", signinbox.show({
                subscribe: 1,
                step: n
            }), updateSignUpClog("subscribe")) : 0 == m && 1 == u && !0 !== a ? yesNoModal.show(o, function() {
                b(e, s, !0)
            }) : 1 == p ? C(modalTranslationText.cannotSubscribe) : MG_Utils.ajaxCall({
                type: "POST",
                url: t,
                dataType: "JSON",
                beforeSend: function() {
                    for (var e = 0; e < i.length; e++) MG_Utils.addClass(i[e], "visuallyHidden");
                    s.insertAdjacentHTML("beforeend", '<span class="spinner" />')
                },
                success: function(e) {
                    for (var t = s.querySelector(".spinner"), a = 0; a < i.length; a++) MG_Utils.removeClass(i[a], "visuallyHidden");
                    if (t && s.removeChild(t), "PASS" == e.success) {
                        if (0 == s.getAttribute("data-subscribed")) {
                            for (a = 0; a < l.length; a++) l[a].setAttribute("data-subscribed", 1);
                            for (a = 0; a < r.length; a++) {
                                MG_Utils.removeClass(r[a], "subscribe"), MG_Utils.addClass(r[a], "unsubscribe");
                                var n = r[a].querySelector("i");
                                n && (MG_Utils.removeClass(n, "ph-icon-rss-feed"), MG_Utils.hasClass(n, "notChanged") || MG_Utils.addClass(n, "ph-icon-already-subscribed"))
                            }
                        } else {
                            for (a = 0; a < l.length; a++) l[a].setAttribute("data-subscribed", 0);
                            for (a = 0; a < r.length; a++) {
                                MG_Utils.removeClass(r[a], "unsubscribe"), MG_Utils.addClass(r[a], "subscribe");
                                var o = r[a].querySelector("i");
                                o && (MG_Utils.removeClass(o, "ph-icon-already-subscribed"), MG_Utils.hasClass(o, "notChanged") || MG_Utils.addClass(o, "ph-icon-rss-feed"))
                            }
                        }
                        1 == c && location.reload()
                    } else s.setAttribute("disabled", 1);
                    if (e.text_initial)
                        for (a = 0; a < d.length; a++) "buttonUnsubscribe" == e.class && (d[a].textContent = e.text_initial, d[a].parentNode.matches(":hover")) ? d[a].textContent = "Unsubscribe" : d[a].textContent = e.text_initial
                },
                error: function() {
                    location.reload()
                }
            })
        }
        return {
            onTextAreaFocus: function(e) {
                (e = e.target) && "TEXTAREA" === e.tagName && e.hasAttribute("data-val") && e.dataset.val == e.value && (e.value = "")
            },
            onBlur: function(e) {
                var t;
                (t = (t = e).target) && "TEXTAREA" === t.tagName && t.hasAttribute("data-val") && "" == t.value && (t.value = t.dataset.val), a(e)
            },
            onKeyUp: function(e) {
                a(e)
            },
            onButtonMouseEnter: function(e) {
                var t, a;
                e.target && MG_Utils.hasClass(e.target, "addFriendButton") ? (a = e.target.querySelector(".buttonLabel"), t = e.target.querySelector("i"), a && "Friends" === a.textContent ? a.textContent = "Unfriend" : a && "Request Sent" === a.textContent && (a.textContent = "Cancel Request"), t && a && a.textContent.indexOf("Add") < 0 && (MG_Utils.removeClass(t, "ph-icon-friend-added"), MG_Utils.addClass(t, "ph-icon-remove-friend"))) : e.target && MG_Utils.hasClass(e.target, "subscribeButton") && (a = e.target.querySelector(".buttonLabel")) && "Subscribed" === a.textContent && (a.textContent = "Unsubscribe")
            },
            onButtonMouseLeave: function(e) {
                var t, a;
                e.target && MG_Utils.hasClass(e.target, "addFriendButton") ? (a = e.target.querySelector(".buttonLabel"), t = e.target.querySelector("i"), a && "Unfriend" === a.textContent ? a.textContent = "Friends" : a && "Cancel Request" === a.textContent && (a.textContent = "Request Sent"), t && a && a.textContent.indexOf("Add") < 0 && (MG_Utils.removeClass(t, "ph-icon-remove-friend"), MG_Utils.hasClass(t, "notChanged") || MG_Utils.addClass(t, "ph-icon-friend-added"))) : e.target && MG_Utils.hasClass(e.target, "subscribeButton") && (a = e.target.querySelector(".buttonLabel")) && "Unsubscribe" === a.textContent && (a.textContent = "Subscribed")
            },
            onSpanMouseOver: function(e) {
                var t;
                e.target && MG_Utils.hasClass(e.target, "js-moreAction") && (t = e.target.querySelector(".tooltiptext"), e = e.target.querySelector(".triangle"), t && MG_Utils.removeClass(t, "hidden"), e) && MG_Utils.removeClass(e, "hidden")
            },
            onSpanMouseOut: function(e) {
                var t;
                e.target && MG_Utils.hasClass(e.target, "js-moreAction") && (t = e.target.querySelector(".tooltiptext"), e = e.target.querySelector(".triangle"), t && MG_Utils.addClass(t, "hidden"), e) && MG_Utils.addClass(e, "hidden")
            },
            documentClick: function(e) {
                var t, a, n, o, s, i, r, l, d, c, u, m;
                if ((p = e).target && "preventClick" === p.target.id && (p = p.target, t = document.querySelector("#messageRequest"), p.setAttribute("disabled", "disabled"), t && "Add a personal message (optional)..." == t.value && (t.value = " "), isLogged) && phubGenericFuncModule.friendReqSubmit(), (p = e).target && ("LI" === p.target.tagName && MG_Utils.hasClass(p.target, "item") || "A" === p.target.tagName && p.target.parentElement && MG_Utils.hasClass(p.target.parentElement, "item") || "SPAN" === p.target.tagName && p.target.parentElement && p.target.parentElement.parentElement && MG_Utils.hasClass(p.target.parentElement.parentElement, "item")) && (t = (p = MG_Utils.hasClass(p.target, "item") ? p.target : (MG_Utils.hasClass(p.target.parentElement, "item") ? p.target : p.target.parentElement).parentElement).querySelectorAll(".soughtValue"), a = MG_Utils.hasClass(p, "pornstar"), n = MG_Utils.hasClass(p, "channel"), m = document.querySelector("#searchInput"), t = t.length ? t[0].textContent : m ? m.value : "", m = {}, p = {
                        to: encodeURI(p.textContent),
                        from: encodeURI(t)
                    }, a ? m.psu = p : n ? m.csu = p : m.qsu = p, phubGenericFuncModule.setCookie("autocomplete_search=" + JSON.stringify(m))), (a = e).target && MG_Utils.hasClass(a.target, "js-okBtn") && (a.preventDefault(), confirmPopUpModal.closeModal()), (n = e).target && ("BUTTON" === n.target.tagName && n.target.parentElement && MG_Utils.hasClass(n.target.parentElement, "addFriendButton") || "SPAN" === n.target.tagName && n.target.parentElement && "BUTTON" === n.target.parentElement.tagName && n.target.parentElement.parentElement && MG_Utils.hasClass(n.target.parentElement.parentElement, "addFriendButton") || "I" === n.target.tagName && n.target.parentElement && "BUTTON" === n.target.parentElement.tagName && n.target.parentElement.parentElement && MG_Utils.hasClass(n.target.parentElement.parentElement, "addFriendButton")) && (n.preventDefault(), o = "BUTTON" === n.target.tagName ? n.target : n.target.parentElement, s = o.children, n = (i = o.parentElement).getAttribute("data-button-id"), r = document.querySelectorAll("." + n), l = document.querySelectorAll("." + n + " .buttonLabel"), d = o.getAttribute("data-friends"), c = o.getAttribute("data-refresh"), u = 2 == d ? o.getAttribute("data-unfriend-url") : o.getAttribute("data-friend-url"), n = o.getAttribute("data-login"), p = o.getAttribute("data-show-confirm-email-modal"), m = o.getAttribute("data-hidden"), 1 == n ? (y("add-friend", o), "function" == typeof triggerSignInSignUpModal && triggerSignInSignUpModal(), updateSignUpClog("add-a-friend")) : 1 == p ? C(modalTranslationText.confirmEmail) : 1 == m ? C(modalTranslationText.cannotAdd) : 1 == d ? MG_Utils.ajaxCall({
                        type: "POST",
                        url: o.getAttribute("data-unfriend-url"),
                        dataType: "JSON",
                        success: function(e) {
                            if ("PASS" == e.success) {
                                o.setAttribute("data-friends", 0), i && MG_Utils.hasClass(i, "updatedStyledBtn") && (MG_Utils.removeClass(o, "friendRequested"), e = o.querySelector("i")) && (MG_Utils.removeClass(e, "ph-icon-remove-friend"), MG_Utils.addClass(e, "ph-icon-add-friend"));
                                for (var t = 0; t < l.length; t++) {
                                    var a = o.querySelector("i.notChanged.ph-icon-remove-friend");
                                    a && MG_Utils.removeClass(a, "ph-icon-remove-friend"), l[t].textContent = "Add Friend"
                                }
                                for (t = 0; t < r.length; t++) MG_Utils.removeClass(r[t], "sent"), MG_Utils.removeClass(r[t], "removeFriend"), MG_Utils.addClass(r[t], "add")
                            }
                        }
                    }) : MG_Utils.ajaxCall({
                        type: "POST",
                        url: u,
                        dataType: "JSON",
                        beforeSend: function() {
                            for (var e = 0; e < s.length; e++) MG_Utils.addClass(s[e], "visuallyHidden");
                            o.insertAdjacentHTML("beforeend", '<span class="spinner" />')
                        },
                        success: function(e) {
                            for (var t = o.querySelector(".spinner"), a = 0; a < s.length; a++) MG_Utils.removeClass(s[a], "visuallyHidden");
                            if (t && o.removeChild(t), "PASS" == e.success) {
                                if (0 == d) {
                                    1 == c && e.auto_accepted && (o.setAttribute("data-friends", 2), location.reload()), o.setAttribute("data-friends", 1);
                                    for (a = 0; a < r.length; a++) MG_Utils.removeClass(r[a], "add"), MG_Utils.addClass(r[a], "removeFriend")
                                } else if (2 == d) {
                                    o.setAttribute("data-friends", 0);
                                    for (a = 0; a < r.length; a++) MG_Utils.removeClass(r[a], "removeFriend"), MG_Utils.addClass(r[a], "add");
                                    1 == c && location.reload()
                                }
                            } else "ATTEMPT" == e.success ? builtModal(e.user.id, e.user.avatar, e.user.username, e.user.profile, u, c) : o.setAttribute("disabled", 1);
                            if (e.text_initial && 0 < l.length)
                                for (var n, a = 0; a < l.length; a++) "remove" == e.class ? (l[a].textContent = e.text_initial, l[a].parentNode.matches(":hover") ? l[a].textContent = "Unfriend" : l[a].textContent = e.text_initial) : ((n = o.querySelector("i.notChanged.ph-icon-remove-friend")) && MG_Utils.removeClass(n, "ph-icon-remove-friend"), l[a].textContent = e.text_initial)
                        },
                        error: function() {
                            location.reload()
                        }
                    })), ((p = e).target && ("BUTTON" === p.target.tagName && p.target.parentElement && MG_Utils.hasClass(p.target.parentElement, "subscribeButton") || "SPAN" === p.target.tagName && p.target.parentElement && "BUTTON" === p.target.parentElement.tagName && p.target.parentElement.parentElement && MG_Utils.hasClass(p.target.parentElement.parentElement, "subscribeButton") || "I" === p.target.tagName && p.target.parentElement && "BUTTON" === p.target.parentElement.tagName && p.target.parentElement.parentElement && MG_Utils.hasClass(p.target.parentElement.parentElement, "subscribeButton")) || MG_Utils.hasClass(p.target, "js_videoSubscribeButton")) && (MG_Utils.hasClass(p.target, "js_videoSubscribeButton") ? b(p, target = document.querySelector(".js_videoSubscribeButton button")) : b(p)), isLogged && (p = e).target && (MG_Utils.hasClass(p.target, "notificationIcon") || "I" === p.target.tagName && p.target.parentElement && MG_Utils.hasClass(p.target.parentElement, "notificationIcon"))) {
                    var p = MG_Utils.hasClass(p.target, "notificationIcon") ? p.target : p.target.parentElement,
                        e = p.dataset ? p.dataset.title : "",
                        g = p.dataset ? p.dataset.type : "",
                        p = document.querySelector("#notificationBox"),
                        h = document.querySelector("#notificationBox .titleContainer"),
                        f = document.querySelector("#notificationBox #loadingDiv"),
                        v = document.querySelectorAll("ul#modelNotificationList > li, .handle3, .track3");
                    h && (h.textContent = e), p && (p.dataset.type = g), p && p.setAttribute("type", g);
                    for (var M = 0; M < v.length; M++) v[M].style.display = "none";
                    f && (f.style.display = "block"), setTimeout(function() {
                        insertNotificationContent(), setActiveStyle(g)
                    }, 100)
                }
            },
            backToPHClick: function() {
                var e = document.querySelector("#js-backToPH"),
                    t = e ? e.dataset : "";
                t && MG_Utils.ajaxCall({
                    url: t.logout,
                    type: "POST"
                }).done(function() {
                    $j.ajax({
                        url: premiumRedirectCookieURL + "&do=delete",
                        cache: !1,
                        xhrFields: {
                            withCredentials: !0
                        },
                        crossDomain: !0
                    }).done(function() {
                        window.location.href = t.redirect
                    })
                })
            }
        }
    }(),
    avatarLoad = function() {
        var l = MG_Utils.hasClass(document.body, "logged-out"),
            d = {
                timer: null,
                el: null
            },
            c = {};

        function e(e) {
            if (e.target && (MG_Utils.hasClass(e.target, "avatarWrap") || MG_Utils.hasClass(e.target, "userLink") || MG_Utils.hasClass(e.target, "usernameWrap"))) {
                var i, r = e.target,
                    t = r.dataset,
                    a = document.querySelectorAll(".avatarPosition");
                if (0 == t.disablePopover) {
                    for (var n = 0; n < a.length; n++) a[n].innerHTML = "";
                    (MG_Utils.hasClass(r, "avatarTrigger") && a.length || MG_Utils.hasClass(r, "usernameWrap") && a.length && (o = (e = e).target, s = (e = e.currentTarget).querySelector(".avatarPosition"), !((!e.contains(o) || s.contains(o)) && e != o)) || MG_Utils.hasClass(r, "userLink")) && (d.timer && clearTimeout(d.timer), i = t.type, d.el = r, d.timer = setTimeout(function() {
                        var e;
                        c[t[i + "id"]] ? l && (e = d.el.querySelector(".avatarPosition")) && (e.innerHTML = c[t[i + "id"]]) : MG_Utils.ajaxCall({
                            type: "POST",
                            url: "/" + i + "/hover?id=" + t[i + "id"],
                            dataType: "text",
                            context: this,
                            cache: !1,
                            success: function(e) {
                                r.querySelector(".avatarPosition").innerHTML = e;
                                for (var t = document.querySelectorAll(".avatarPopOver"), a = 0; a < t.length; a++) t[a].style.display = "none";
                                r.querySelector(".avatarPopOver") && (r.querySelector(".avatarPopOver").style.display = "block");
                                var e = document.querySelector(".avatarPopOver"),
                                    n = e ? e.getBoundingClientRect() : null,
                                    n = n ? n.left : 0,
                                    o = e ? e.offsetWidth : 0,
                                    s = document.querySelector(".wrapper") ? document.querySelector(".wrapper").offsetWidth : 0;
                                e && (s < n + o ? MG_Utils.addClass(e, "popOverEdge") : MG_Utils.removeClass(e, "popOverEdge")), l && (c[d.el.dataset[i + "id"]] = d.el.querySelector(".avatarPosition") ? d.el.querySelector(".avatarPosition").innerHTML : "")
                            }
                        })
                    }, 500))
                }
            }
            var o, s
        }

        function t(e) {
            var t, a, n, o;
            e.target && (MG_Utils.hasClass(e.target, "avatarWrap") || MG_Utils.hasClass(e.target, "userLink") || MG_Utils.hasClass(e.target, "usernameWrap")) && (a = (t = e.target).dataset, n = "", o = document.querySelector(".avatarPopOver"), 0 == a.disablePopover) && (n = t.dataset ? t.dataset.type : "", l && (c[e.target.dataset[n + "id"]] = e.target.querySelector(".avatarPosition") ? e.target.querySelector(".avatarPosition").innerHTML : ""), o && (o.style.display = "none"), o && document.body.insertAdjacentElement("beforeend", o), clearTimeout(d.timer))
        }
        return {
            init: function() {
                document.body.addEventListener && (document.body.addEventListener("mouseenter", e, !0), document.body.addEventListener("mouseleave", t, !0), document.querySelectorAll(".js-accessiblePopUp").length) && (document.body.addEventListener("focus", e, !0), document.body.addEventListener("blur", t, !0))
            }
        }
    }();

function showMainHubWelcomeModal() {
    var e = document.getElementById("mainHubWelcomeModal");
    e && (mainHubWelcomeModal = new MG_Modal({
        content: e,
        className: "mainHubWelcomeModalContainer",
        closeButton: !0,
        closeDocument: !1
    })).openModal(function(e, t) {
        function a() {
            "undefined" != typeof MAINHUB_WELCOME_MODAL && MG_Utils.ajaxCall({
                url: MAINHUB_WELCOME_MODAL.doNotShowAgainUrl,
                type: "POST",
                success: function(e) {
                    e.success && mainHubWelcomeModal.closeModal()
                }
            })
        }
        var n = t.querySelector(".okayButton"),
            t = t.querySelector(".closeMTubes");
        n && n.addEventListener("click", a), t && t.addEventListener("click", a)
    })
}
var PH_PasswordChangeModalCmp = function() {
    var d = this,
        c = {
            passwordChangeModal: document.getElementById("passwordChangeModal"),
            displayNoneClass: "displayNone",
            charactersText: " characters",
            visiblitilyOn: "ph-icon-view-off",
            visiblitilyOff: "ph-icon-view-on"
        },
        u = null;
    d.init = function() {
        c.passwordChangeModal && (mainPasswordChangeModal = new MG_Modal({
            content: c.passwordChangeModal,
            className: "passwordChangeModalContainer",
            closeButton: !1,
            closeDocument: !1
        })).openModal(function(e, t) {
            let a = t.querySelector(".passwordChangeInWrap.stepOne .content button"),
                n = t.querySelector("#modal_password_old"),
                o = t.querySelector("#modal_originalPassword"),
                s = t.querySelector("#modal_newPassword"),
                i = t.querySelectorAll("[data-modal-visiblitily]"),
                r = t.querySelector(".passwordChangeBtn"),
                l = t.querySelector("#updatePasswordForm");
            "undefined" != typeof loadCaptchaV3 && loadCaptchaV3(), a && a.addEventListener("click", d.goToStepTwo), o && o.addEventListener("keyup", d.onkeyupInput), s && s.addEventListener("keyup", d.onkeyupInput), r && r.addEventListener("click", e => d.submitPasswordChange(e, l)), n && n.addEventListener("keyup", d.onkeyupInput), i && i.forEach(function(e) {
                e.addEventListener("click", d.triggerVisibility)
            })
        })
    }, d.triggerVisibility = function(e) {
        var e = e.target || e.srcElement,
            t = document.getElementById(e.dataset.modalVisiblitily);
        e.classList.contains(c.visiblitilyOn) ? (e.classList.remove(c.visiblitilyOn), e.classList.add(c.visiblitilyOff), t.type = "text") : (e.classList.add(c.visiblitilyOn), e.classList.remove(c.visiblitilyOff), t.type = "password")
    }, d.goToStepTwo = function(e) {
        var t = document.querySelector("#modalWrapMTubes.passwordChangeModalContainer .passwordChangeWrapper .passwordChangeInWrap.stepOne"),
            a = document.querySelector("#modalWrapMTubes.passwordChangeModalContainer .passwordChangeWrapper .passwordChangeInWrap.stepTwo");
        t.classList.contains(c.displayNoneClass) || t.classList.add(c.displayNoneClass), a.classList.contains(c.displayNoneClass) && a.classList.remove(c.displayNoneClass)
    }, d.serializeData = function(e) {
        for (var t = document.querySelectorAll(e), a = {}, n = 0; n < t.length; n++) a[t[n].name] = t[n].value;
        return a
    }, d.createPopUp = function() {
        let e = document.createElement("div");
        e.classList.add("passwordChangedBanner"), e.innerHTML = '<p><i class="ph-icon-check"></i>' + PASSWORD_CHANGE.passwordChanged + '</p><span class="closePWbanner"><i class="ph-icon-cross"></i></span>', document.body.appendChild(e), setTimeout(function() {
            e.remove()
        }, 5e3)
    }, d.onkeyupInput = function(e) {
        let t = e.target || e.srcElement,
            a = document.querySelector('[data-for="' + t.id + '"]'),
            n = document.querySelector(".stepTwo #modal_password_old"),
            o = document.querySelector(".stepTwo #modal_originalPassword"),
            s = document.querySelector(".stepTwo #modal_newPassword"),
            i = document.querySelector(".stepTwo #strengthValue"),
            r = document.querySelector(".stepTwo #js-passwordError"),
            l = document.querySelector(".stepTwo #passwordChangeSubmit");
        clearTimeout(u), o.value ? (MG_Utils.addClass(l, "disabled"), l.setAttribute("disabled", "disabled"), u = setTimeout(function() {
            MG_Utils.ajaxCall({
                url: PASSWORD_CHANGE.checkPasswordUrl,
                data: {
                    old_password: n.value,
                    password: o.value,
                    password_confirmation: s.value
                },
                type: "POST",
                success: function(e) {
                    i.removeAttribute("class"), i && (i.innerHTML = e.strengthMessage), 1 === e.strengthScore ? MG_Utils.addClass(i, "strWeak") : 2 === e.strengthScore ? MG_Utils.addClass(i, "strFair") : 3 === e.strengthScore ? MG_Utils.addClass(i, "strStrong") : 4 === e.strengthScore && MG_Utils.addClass(i, "strVeryStrong"), e.error || o.value !== s.value ? r && (r.innerHTML = e.error) : (r && (r.innerHTML = ""), MG_Utils.removeClass(l, "disabled"), l.removeAttribute("disabled"))
                }
            })
        }, 500), a && (0 < t.value.length ? a.innerHTML = t.value.length + c.charactersText : a.innerHTML = "")) : (i && (i.innerHTML = ""), r && (r.innerHTML = ""))
    }, d.submitPasswordChange = function(t, a) {
        let n = a.querySelector("#captcha_token"),
            o = a.querySelector("#captcha_type");
        "score" === o.value ? recaptchaUtils.executeCaptchaV3(function(e) {
            n.value = e, MG_Utils.ajaxCall({
                url: t.target.getAttribute("data-url"),
                data: d.serializeData('#updatePasswordForm input:not([type="button"])'),
                type: "POST",
                success: function(e) {
                    e.showCaptchav2 ? (void 0 !== recaptchaUtils.unloadCaptchaV3 && recaptchaUtils.unloadCaptchaV3(), void 0 !== recaptchaUtils.loadCaptchaV2 && recaptchaUtils.loadCaptchaV2(), MG_Utils.addClass(passwordChangeSubmit, "disabled"), passwordChangeSubmit.setAttribute("disabled", "disabled"), recaptchaUtils.renderCaptchaV2(a.querySelector(".g-recaptcha"), function(e) {
                        n.value = e, o.value = "checkbox", MG_Utils.removeClass(passwordChangeSubmit, "disabled"), passwordChangeSubmit.removeAttribute("disabled")
                    }, function(e) {
                        console.log(e)
                    })) : (mainPasswordChangeModal.closeModal(), d.createPopUp())
                }
            })
        }) : MG_Utils.ajaxCall({
            url: t.target.getAttribute("data-url"),
            data: d.serializeData('#updatePasswordForm input:not([type="button"])'),
            type: "POST",
            success: function(e) {
                !1 === e.success ? (recaptchaUtils.resetRecaptcha(), MG_Utils.addClass(passwordChangeSubmit, "disabled"), passwordChangeSubmit.setAttribute("disabled", "disabled")) : (mainPasswordChangeModal.closeModal(), d.createPopUp())
            }
        })
    }
};

function loadJS(e, t) {
    MG_Utils.ajaxCall({
        url: e,
        dataType: "script"
    }).done(function() {
        "function" == typeof t && t()
    })
}
MG_Utils.domReady(function() {
        try {
            (passwordChangeModal = new PH_PasswordChangeModalCmp).init()
        } catch (e) {
            console.log(e)
        }
        showMainHubWelcomeModal(), document.addEventListener("click", eventsModule.documentClick);
        for (var e = document.querySelectorAll("a.relatedItem"), t = document.querySelectorAll(".js-trendSearch"), a = (document.querySelectorAll("ul#curentItemCategory li"), document.querySelector(".nf-categories-sidebar .sidebar_wrapper.categoryMenu")), n = document.querySelectorAll(".js-moreAction"), o = document.querySelectorAll("#languages li a, .languages li a"), s = document.querySelector("#js-backToPH"), i = document.querySelector(".js_premiumLogOut"), r = 0; r < e.length; r++) e[r].addEventListener("click", function() {
            var e = document.querySelector("#searchInput"),
                e = {
                    from: encodeURI(e ? e.value.trim() : "")
                };
            phubGenericFuncModule.setCookie("related_search=" + JSON.stringify(e))
        });
        for (r = 0; r < t.length; r++) t[r].addEventListener("click", function() {
            phubGenericFuncModule.setCookie("trending_search= " + encodeURI(this.textContent))
        });
        avatarLoad.init(), document.body.addEventListener && (document.body.addEventListener("focus", eventsModule.onTextAreaFocus, !0), document.body.addEventListener("blur", eventsModule.onBlur, !0), document.body.addEventListener("keyup", eventsModule.onKeyUp, !0), document.body.addEventListener("mouseenter", eventsModule.onButtonMouseEnter, !0), document.body.addEventListener("mouseleave", eventsModule.onButtonMouseLeave, !0), document.body.addEventListener("mouseover", eventsModule.onSpanMouseOver, !0), document.body.addEventListener("mouseout", eventsModule.onSpanMouseOut, !0)), a && MG_Utils.addClass(a, "domReady"), isLarge && MG_Utils.addClass(document.querySelector("html"), "largeLayout");
        for (r = 0; r < n.length; r++) n[r].addEventListener("click", function(e) {
            e.target && e.target.parentElement && (e = e.target.parentElement.querySelector("#profileBlockReport .blockAndReportSubscribers")) && MG_Utils.toggleClass(e, "hidden")
        });
        for (r = 0; r < o.length; r++) o[r].addEventListener("click", function() {
            if (setCookieAdvanced("lang", this.dataset.lang, 30, "/", this.dataset.root), location.hash != this.hash) return location.href = (-1 == this.href.indexOf("#") ? this.href : this.href.substring(0, this.href.indexOf("#"))) + location.hash, !1
        });
        s && s.addEventListener("click", eventsModule.backToPHClick), i && i.addEventListener("click", function(e) {
            e.preventDefault();
            var t = this.getAttribute("href");
            $j.ajax({
                url: premiumRedirectCookieURL + "&do=delete",
                cache: !1,
                crossDomain: !0,
                xhrFields: {
                    withCredentials: !0
                }
            }).done(function() {
                MG_Utils.storage.hasLocalStorage && localStorage.getItem("covidPageViewCount") && localStorage.removeItem("covidPageViewCount"), document.location.href = t
            })
        }), document.getElementById("js-networkBar") && setTimeout(function() {
            var e = document.getElementById("js-networkBar").querySelector(".languageDropdown");
            e && (e = e.querySelectorAll("li")) && [].forEach.call(e, function(t) {
                t.addEventListener("click", function() {
                    var e = MG_Utils.getData(t, "lang");
                    setCookieAdvanced("lang", e, 30, "/", removeSubdomain(window.location.host))
                })
            })
        }, 100), isLogged && ($j("#notificationBox").on("click", ".subscribeConfirm label", function(e) {
            var t = e.currentTarget.parentElement.querySelector("input"),
                e = e.currentTarget.querySelector(".fakeCheckBox");
            t.checked ? MG_Utils.removeClass(e, "checked") : MG_Utils.addClass(e, "checked")
        }), $j("#notificationBox").on("click", ".friendRequestItem .btnFlag", function() {
            var e = this;
            yesNoModal.show("Are you sure you want to report as spam and reject this request?", function() {
                reportSpam(e.dataset.userid)
            }, null, null, null, "redesign_menu")
        }), $j("#notificationBox").on("click", function(e) {
            e.stopPropagation()
        }));
        const l = document.getElementById("mainHubToastMessage"),
            d = (l && MG_Utils.addClass(l, "showToast"), document.getElementById("limitSpamToastMessage")),
            c = (d && MG_Utils.addClass(d, "showToast"), document.addEventListener("click", function(e) {
                if (e.target && MG_Utils.hasClass(e.target, "js-closeToast")) {
                    const t = e.target.dataset,
                        a = t ? e.target.dataset.url : null,
                        n = t ? e.target.dataset.flag : null;
                    a && n ? MG_Utils.ajaxCall({
                        url: a,
                        type: "POST",
                        data: {
                            dismissal_source: n
                        },
                        success: function(e) {
                            e && e.success && ("51" == n ? (l && MG_Utils.removeClass(l, "showToast"), l && l.remove()) : "52" == n && ((e = document.getElementById("socialMediaToastMessage")) && MG_Utils.removeClass(e, "showToast"), e && e.remove(), l) && MG_Utils.removeClass(l, "shiftToastUp"))
                        }
                    }) : (d && MG_Utils.removeClass(d, "showToast"), d && d.remove())
                }
            }), document.getElementById("leftMenu")),
            u = document.getElementById("leftMenuScroll"),
            m = document.querySelector(".menuFadeOutOverly");
        "undefined" != typeof MG_Scroll && u && (u.style.maxHeight = window.innerHeight - 135 + "px", MG_Scroll.init({
            width: "auto",
            selector: document.querySelectorAll("#leftMenuScroll"),
            height: "100%",
            color: "#FF9000",
            size: "4px",
            alwaysVisible: !0,
            railVisible: !0,
            railOpacity: 1,
            railColor: "transparent",
            distance: "5px",
            opacity: 1,
            railClass: "track3",
            barClass: "handle3 js_hamburgerMenuScroll",
            wrapperClass: "wrapper3",
            wheelStep: 5,
            enLargeOnHover: !0,
            enLargedSize: "8px"
        }));
        var p = document.querySelector(".js_hamburgerMenuScroll"),
            g = !1;
        if (document.addEventListener("mousedown", function(e) {
                g = c && c.contains(e.target)
            }), document.addEventListener("click", function(e) {
                var e = e.target,
                    t = e && e.id;
                !e || "desktopNavigation" === t || MG_Utils.hasClass(e, "menuWrapper") || MG_Utils.hasClass(e, "menuLink") || MG_Utils.hasClass(e, "subMenuTrigger") || MG_Utils.hasClass(e, "subMenuMainLink") || MG_Utils.hasClass(e, "js-menuAnalytics") || MG_Utils.hasClass(e, "menuFadeOutOverly") || MG_Utils.hasClass(e, "js_chevronRight") || g ? t && "desktopNavigation" === t && c && MG_Utils.toggleClass(c, "active") : c && MG_Utils.removeClass(c, "active"), !u || u.scrollTop + 2 + u.clientHeight >= u.scrollHeight ? m && MG_Utils.addClass(m, "hidden") : m && MG_Utils.removeClass(m, "hidden")
            }), u && MG_Utils.addEventHandler(u, "scroll", function() {
                u.scrollTop + 2 + u.clientHeight >= u.scrollHeight ? MG_Utils.addClass(m, "hidden") : MG_Utils.removeClass(m, "hidden")
            }), m && MG_Utils.addEventHandler(m, "click", function() {
                var e;
                u && p && (e = u.clientHeight - p.offsetHeight, u.scrollTo({
                    top: u.scrollHeight,
                    behavior: "smooth"
                }), MG_Utils.addClass(m, "hidden"), p.style.top = e + "px")
            }), document.addEventListener("click", function(e) {
                var t, a = e.target,
                    e = e.target && e.target.parentNode;
                let n, o, s;
                if (a && MG_Utils.hasClass(a, "subMenuTrigger") || e && MG_Utils.hasClass(e, "subMenuTrigger")) {
                    const i = MG_Utils.closest(a, ".subMenuTriggerwithLink"),
                        r = i && i.nextElementSibling,
                        l = i && i.querySelector(".subMenuTrigger");
                    r && i && (MG_Utils.hasClass(r, "active") ? (MG_Utils.removeClass(r, "active"), MG_Utils.removeClass(l, "ph-icon-arrow-drop-up"), MG_Utils.hasClass(i, "activeSub") && r.addEventListener("transitionend", function() {
                        MG_Utils.removeClass(i, "activeSub")
                    }), MG_Utils.addClass(l, "ph-icon-arrow-drop-down")) : (MG_Utils.addClass(r, "active"), MG_Utils.removeClass(l, "ph-icon-arrow-drop-down"), MG_Utils.addClass(i, "activeSub"), r.addEventListener("transitionend", function() {
                        MG_Utils.hasClass(i, "activeSub") || MG_Utils.addClass(i, "activeSub")
                    }), MG_Utils.addClass(l, "ph-icon-arrow-drop-up")))
                }(s = a && "locationMenu" !== a.id && (MG_Utils.closest(a, ".js-subMenu") && (t = (t = MG_Utils.closest(a, ".js-subMenu")) && t.previousElementSibling, o = t && t.innerText), MG_Utils.hasClass(a, "js-menuAnalytics") ? n = a.innerText : MG_Utils.hasClass(a, "svgSpriteIcon") || MG_Utils.closest(a, ".svgSpriteIcon") ? (t = MG_Utils.closest(a, ".svgSpriteIcon") ? MG_Utils.closest(a, ".svgSpriteIcon") : a, n = t.parentNode && t.parentNode.innerText) : e && MG_Utils.hasClass(e, "js-menuAnalytics") && (n = e.innerText), MG_Utils.closest(a, "#leftMenu")) ? "Hamburger Menu" : s) && n && "function" == typeof ga && ga("send", "event", s, "click", (o ? o + "-" : "") + n.trim())
            }), "undefined" != typeof isUpdatedUserMenu && isUpdatedUserMenu) {
            const v = document.getElementById("profileMenuDropdownScroll"),
                M = document.querySelector("#profileMenuWrapper .dropdownTrigger");
            v && (v.style.maxHeight = window.innerHeight - 210 + "px"), MG_Scroll.init({
                width: "auto",
                selector: document.querySelectorAll("#profileMenuDropdownScroll"),
                height: "100%",
                color: "#FF9000",
                size: "5px",
                alwaysVisible: !0,
                railVisible: !0,
                railOpacity: 1,
                railColor: "#151515",
                wheelScrollAllowClass: "js_WheelScrollAllow",
                distance: "5px",
                opacity: 1,
                railClass: "track3",
                barClass: "handle3 js_userMenuScroll",
                wrapperClass: "scrollContentWrapper",
                wheelStep: 5,
                enLargeOnHover: !0,
                enLargedSize: "8px"
            }), window.addEventListener("resize", function() {
                v && (v.style.maxHeight = window.innerHeight - 210 + "px")
            }), M && M.addEventListener("click", function() {
                MG_Scroll.showDefault()
            })
        }
        a = document.getElementById("recommendSwitch");
        a && a.addEventListener("change", function() {
            let e, t = new XMLHttpRequest;
            this.disabled = !0, e = this.checked ? this.dataset.showUrl : this.dataset.hideUrl, t.open("GET", e), t.send(), setTimeout(function() {
                location.replace(location.href)
            }, 1e3)
        });
        let h = document.getElementById("changeLegalTextLang"),
            f = document.getElementById("langNameSpan");
        h && h.addEventListener("change", function(e) {
            var t = this.selectedOptions[0];
            f && (f.innerHTML = t.text), MG_Utils.setCookie("legalTextLangId", parseInt(t.value)), window.location.reload()
        }.bind(h))
    }),
    function() {
        var s, i, r, e;
        i = document.querySelector(".js-elInViewPort"), r = MG_Utils.debounce(function() {
            var e, t, a = 0,
                n = document.querySelectorAll(".js-whenInView"),
                o = n.length;
            if (e = (e = i).getBoundingClientRect(), t = document.documentElement, 0 <= e.bottom && 0 <= e.right && e.top <= (window.innerHeight || t.clientHeight) && e.left <= (window.innerWidth || t.clientWidth))
                if (s) window.removeEventListener("scroll", r);
                else if (n && o) {
                for (; a < o; a++) n[a].setAttribute("src", n[a].getAttribute("data-image"));
                s = !0
            }
        }, 125), {
            init: function() {
                i && window.addEventListener("scroll", r)
            }
        }.init(), (e = document.querySelector(".relatedCategoriesWrapper")) && 0 == e.querySelector(".nf-categories").querySelectorAll(".show").length && MG_Utils.addClass(e, "hidden")
    }(),
    function() {
        if ("undefined" != typeof MPP_EXCLUSIVE_TERMS) try {
            var e = document.getElementById("modelMPPExclusive"),
                d = new MG_Modal({
                    content: e,
                    className: "modelMPPExclusiveModal",
                    closeButton: !1,
                    closeDocument: !1,
                    maxWidth: "500px",
                    minWidth: "500px"
                });
            d.openModal(function() {
                var e, t, a, n, o, s, i, r, l = document.getElementById("modalWrapMTubes");
                l && (e = l.querySelector(".modelMPPForm"), t = l.querySelector(".modelMPPSubmit"), a = l.querySelector(".js-modelMPPInputIntial"), n = l.querySelector(".js-modelMPPError"), o = l.querySelector(".js-modelMPPErrorMessage"), s = {
                    errors: [],
                    checked: !1
                }, i = function(e) {
                    if (s.errors.push(e), n && o) return MG_Utils.removeClass(n, "isHidden"), s.errors.forEach(function(e) {
                        o.innerHTML = e
                    })
                }, r = function() {
                    n && o && (MG_Utils.addClass(n, "isHidden"), o.innerHTML = "")
                }, document.addEventListener("change", function(e) {
                    MG_Utils.hasClass(e.target, "js-modelMPPInput") && (r(), s.checked = !0)
                }), document.addEventListener("click", function(e) {
                    if (MG_Utils.hasClass(e.target, "modelMPPSubmit")) return e.preventDefault(), s.checked ? "" === a.value ? i(MPP_EXCLUSIVE_TERMS.errorIntials) : 3 <= a.value.length ? i(MPP_EXCLUSIVE_TERMS.errorLimit) : void MG_Utils.ajaxCall({
                        url: MPP_EXCLUSIVE_TERMS.endPoint,
                        data: {
                            exclusive: l.querySelector(".js-modelMPPInput:checked").value,
                            initials: l.querySelector(".js-modelMPPInputIntial").value
                        },
                        type: "POST",
                        success: function(e) {
                            e.success ? d.closeModal() : 3 === (e = e.message).code ? i(MPP_EXCLUSIVE_TERMS.errorAlpha) : i(e.text)
                        }
                    }) : i(MPP_EXCLUSIVE_TERMS.errorChecked)
                }), document.addEventListener("focus", function(e) {
                    MG_Utils.hasClass(e.target, "js-modelMPPInputIntial") && r()
                }, !0), a.addEventListener("keyup", function() {
                    13 === event.keyCode && t.click()
                }), e.addEventListener("submit", function(e) {
                    e.preventDefault()
                }))
            })
        } catch (e) {
            console.log("MPP Eclusive: ", e)
        }
    }();
var resetPasswordForm = document.getElementById("resetPasswordForm"),
    pwdInput = resetPasswordForm && resetPasswordForm.elements.password,
    pwdInputAgain = resetPasswordForm && resetPasswordForm.elements.passwordAgain,
    matchError = resetPasswordForm && resetPasswordForm.querySelector(".matchError"),
    phCustomEvent = (resetPasswordForm && resetPasswordForm.addEventListener("submit", function(e) {
        var t;
        e.preventDefault(), matchError && (matchError.innerHTML = ""), pwdInput && pwdInputAgain && matchError && "undefined" != typeof PASSWORD_RESET && (e = pwdInput.value, t = pwdInputAgain.value, grecaptcha && grecaptcha.enterprise.getResponse().length ? (e || t) && (e.length < 6 ? matchError.innerHTML = PASSWORD_RESET.passwordShort : /([a-zA-Z0-9_-])\1\1/.test(e) ? matchError.innerHTML = PASSWORD_RESET.passwordInvalid : PASSWORD_RESET.userName && e.toLowerCase() == PASSWORD_RESET.userName.toLowerCase() ? matchError.innerHTML = PASSWORD_RESET.passwordUsername : e !== t ? matchError.innerHTML = PASSWORD_RESET.passwordMatch : (matchError.innerHTML = "", this.submit())) : matchError.innerHTML = PASSWORD_RESET.captcha)
    }), function() {
        "use strict";
        var n = {};
        return {
            dispatch: function(t, a) {
                n.hasOwnProperty(t) && [].forEach.call(n[t], function(e) {
                    try {
                        e.callback(t, a)
                    } catch (e) {
                        console.log("Error dispatching event ", e)
                    }
                })
            },
            subscribe: function(e, t) {
                t = {
                    callback: t
                };
                n[e] ? n[e].push(t) : n[e] = [t]
            },
            unsubscribe: function(e, t) {
                for (var a = n[e].length; a--;) n[e].splice(a, 1), t && t(e)
            }
        }
    }());

function userSignUpClog(e, t, a, n, o, s) {
    var o = o ? "&origin_item_id=" + o : "",
        i = 1 < n.length ? "&origin_url=" + encodeURIComponent(n) : "",
        n = 1 < n.length ? "&origin=" + a : "",
        a = "&origin_item_variation=" + s;
    let r = "";
    void 0 !== page_params["geo-localization"] && "all" != page_params["geo-localization"] && (r = "&geo-localization=" + page_params["geo-localization"]);
    var l = "";
    if ("undefined" != typeof page_params && page_params.subdomain && "signup-open" == t) switch (page_params.subdomain) {
        case "es":
            l = "&geo-localization=spanish";
            break;
        case "jp":
            l = "&geo-location=japan";
            break;
        default:
            l = ""
    }
    MG_Utils.ajaxCall({
        url: e + "/_i?type=event&event=" + t + n + i + o + a + r + l,
        type: "POST"
    })
}

function updateSignUpClog(e) {
    clickedElement = e
}
Vue.customElement("notifications-list", {
        props: {
            countReceiverId: {
                type: String
            }
        },
        data() {
            return {
                list: [],
                dataLoaded: !1,
                newNotificationsCount: 0
            }
        },
        computed: {
            shortList() {
                var e = 7 < this.newNotificationsCount ? 7 : this.newNotificationsCount;
                return this.list.slice(0, e)
            },
            translation: function() {
                return "undefined" != typeof WiDGET_NOTIFICATION_ICONS ? WiDGET_NOTIFICATION_ICONS.translation : {}
            },
            notificationsPageUrl: function() {
                return "undefined" != typeof WiDGET_NOTIFICATION_ICONS ? WiDGET_NOTIFICATION_ICONS.notificationsPageUrl : {}
            },
            spinnerImgUrl: function() {
                return "undefined" != typeof WiDGET_NOTIFICATION_ICONS ? WiDGET_NOTIFICATION_ICONS.ajaxLoader : ""
            }
        },
        methods: {
            async loadNotifications() {
                var e;
                this.dataLoaded = !1, "undefined" != typeof notificationClient && (this.list = await notificationClient.getNotifications(), this.dataLoaded = !0, e = await notificationClient.getCount(), this.newNotificationsCount = e, phCustomEvent.dispatch("new-notification-count", {
                    countReceiverId: this.countReceiverId,
                    count: e
                }))
            },
            initCustomScroll(e) {
                MG_Scroll.init({
                    selector: e,
                    height: "360px",
                    color: "#FF9000",
                    size: "4px",
                    alwaysVisible: !0,
                    railVisible: !0,
                    railOpacity: 1,
                    railColor: "transparent",
                    distance: "5px",
                    opacity: 1,
                    railClass: "track3",
                    barClass: "handle3",
                    wrapperClass: "wrapper3",
                    enLargeOnHover: !0,
                    enLargedSize: "8px"
                })
            },
            resetNotificationCount() {
                phCustomEvent.dispatch("new-notification-count", {
                    countReceiverId: this.countReceiverId,
                    count: 0
                }), this.newNotificationCount = 0, this.list = []
            }
        },
        mounted() {
            let a = this;
            this.loadNotifications(), "undefined" != typeof notificationClient && (notificationClient.onNewNotification(async ({
                notification: e,
                count: t
            }) => {
                a.list.unshift(e), a.newNotificationsCount = t, phCustomEvent.dispatch("new-notification-count", {
                    countReceiverId: a.countReceiverId,
                    count: t
                })
            }), document.querySelector(".js-notificationsLink").addEventListener("click", this.resetNotificationCount)), this.initCustomScroll(this.$refs.notificationsDrawer)
        },
        template: `
            <div ref="notificationsDrawer" class="notifications-list">
                <div id="notificationsLoader" v-if="!dataLoaded">
                    <img :src='spinnerImgUrl' width='32' height='32' :alt="translation.loadingTxt">
                </div>
                <template v-else>
                    <template>
                        <div class="noResultsText" v-if="!shortList.length">{{ translation.noNewNotifications }}</div>
                        <template v-else  v-for="item in shortList">
                            <notification-item short :item="item" :key="item.timestamp"></notification-item>
                        </template>
                    </template>
                </template>
                    <div class="notifications-drawer-footer" v-if="newNotificationsCount > 7">
                    <a :href="notificationsPageUrl" class="btn-more" @click="resetNotificationCount">
                    {{translation.moreNotificationsExist}}
                    </a>
                </div>
            </div>`
    }), Vue.component("notification-item", {
        props: ["item"],
        data() {
            return {
                timeAgo: " ",
                interval: 1e3,
                timer: null
            }
        },
        methods: {
            timeSince(e) {
                var t = 86400,
                    e = Math.floor((Date.now() - e) / 1e3);
                if (e < 10) return "just now";
                if (e < 60) return "less than a minute ago";
                this.interval = 6e4;
                t = (e < 3600 ? [Math.floor(e / 60), "minute"] : e < t && [Math.floor(e / 3600), "hour"]) || (e < 2592e3 ? [Math.floor(e / t), "day"] : e < 31536e3 && [Math.floor(e / 2592e3), "month"]) || [Math.floor(e / 31536e3), "year"];
                return t[0] + " " + t[1] + (1 === t[0] ? "" : "s") + " ago"
            },
            capitalizeFirstLetter(e = "") {
                return e.charAt(0).toUpperCase() + e.slice(1)
            },
            getNotificationSourceImg: function(e) {
                return e.AVATAR_URI
            }
        },
        mounted: function() {
            const e = () => this.timeAgo = this.timeSince(new Date(this.item.timestamp));
            this.item.timestamp && (this.timer = setInterval(() => {
                e()
            }, this.interval)), e()
        },
        beforeUnmount: function() {
            clearInterval(this.timer)
        },
        template: `
                <div class="single-notification">
                    <div class="notification-source" :class="{aggregated:item.isAggregated}">
                        <img :src="getNotificationSourceImg(item)" alt="">
                        <div class="notification-source-icon">
                            <v-svg-icon :name="'notification'+capitalizeFirstLetter(item.type)" :width="item.isAggregated?24:10" :height="item.isAggregated?24:10"></v-svg-icon>
                        </div>
                    </div>
                    <div class="notification-info-holder">
                        <div class="notification-text" v-html="item.text"></div>
                    <div class="notification-time">{{ timeAgo }}</div>
                    </div>
                </div>
        `
    }), Vue.customElement("v-drawer", {
        props: {
            badge: {
                type: Number,
                default: 0
            },
            id: {
                type: String,
                default: ""
            },
            redirect: {
                type: String,
                default: ""
            }
        },
        data() {
            return {
                isOpen: !1,
                count: 0
            }
        },
        watch: {
            badge(e) {
                this.count = e
            }
        },
        methods: {
            toggle() {
                this.redirect ? (this.count = 0, window.location = this.redirect) : (this.isOpen = !this.isOpen, this.isOpen && (this.$emit("open"), phCustomEvent.dispatch("open-drawer", {
                    count: this.count,
                    parentId: this.id
                })))
            },
            hide() {
                this.isOpen = !1
            }
        },
        mounted() {
            const n = this;
            document.addEventListener("click", function(e) {
                e.target.closest("#" + n.$el.id) || n.hide()
            }), phCustomEvent.subscribe("new-notification-count", function(e, {
                countReceiverId: t,
                count: a
            }) {
                t === n.id && 0 === (n.count = a) && n.hide()
            })
        },
        template: `
            <div class="drawer-container" :id="id">
                <div :class="['drawer-button', {active: isOpen}]" @click="toggle">
                    <slot name="icon"></slot>
                    <span v-if="count" class="drawer-badge">{{ count }}</span>
                </div>
                <div :class="['drawer-content', {open: isOpen}]" v-show="isOpen">
                    <slot></slot>
                </div>
            </div>
        `
    }),
    function() {
        var t, e = document.getElementById("loginModal2fa");

        function a() {
            let e = document.getElementById("loginModal2fa").dataset.cookiedomain;
            0 === e.indexOf("www.") ? e = e.replace("www.", ".") : 0 !== e.indexOf(".") && (e = "." + e), "undefined" != typeof COOKIE_DOMAIN && (e = COOKIE_DOMAIN), setCookieAdvanced("email2faModal", 1, -1, "/", e)
        }
        e && ((t = new MG_Modal({
            content: e,
            className: "loginModal2fa",
            closeButton: !1,
            closeDocument: !1
        })).openModal(), (e = document.querySelectorAll(".js-close2faModal"))[0] && MG_Utils.addEventHandler(e[0], "click", function(e) {
            e.preventDefault(), a(), t.closeModal()
        }), e = document.querySelectorAll(".loginModal2fa .buttonBase")) && e.forEach(e => {
            e.addEventListener("click", a)
        })
    }();
var promotionalContentHandler = {
    characterCounter: function(e, t, a) {
        e && t && a && (t = document.querySelector(t), a = (a = document.querySelector(a)) && a.querySelector("span"), t = t && t.value.length, a) && (a.innerHTML = e - t)
    },
    restoreCounter: function(e, t) {
        e && t && (t = (t = document.querySelector(t)) && t.querySelector("span")) && (t.innerHTML = e)
    },
    removeInvalidCharacters: function(e) {
        var t = document.querySelector(e);
        if (t)
            for (var a = t.value, n = 0; n < a.length; n++)(a.charCodeAt(n) <= 31 || 60 == a.charCodeAt(n) || 62 == a.charCodeAt(n)) && (t.value = a.replace(a[n], ""))
    }
};
! function() {
    var e = document.getElementById("mppUserLoginUpdateTemp");
    e && new MG_Modal({
        content: e,
        className: "importantLoginUpdateModal",
        closeButton: !1,
        closeDocument: !1
    }).openModal()
}(),
function() {
    var e = document.getElementById("userLoginUpdateTemp");
    if (e) {
        let u = new MG_Modal({
            content: e,
            className: "userLoginUpdateModal",
            closeButton: !1,
            closeDocument: !1
        });
        u.openModal(function(e, a) {
            const n = a.querySelector("h1"),
                o = a.querySelector(".modal-body .step1"),
                s = a.querySelector(".modal-body .step2"),
                t = a.querySelector(".reviewBtn"),
                i = a.querySelector(".confirmBtn"),
                r = a.querySelector("#confirmEmailInput"),
                l = document.getElementById("toastMessageConfirmation"),
                d = l ? l.querySelector(".closeBtn") : null;

            function c(e) {
                var t;
                e.target && MG_Utils.hasClass(e.target, "reviewBtn") ? (t = a.querySelector(".progressBarRight"), MG_Utils.addClass(e.target, "hidden"), MG_Utils.removeClass(i, "hidden"), n && (n.textContent = USER_UPDATE_TEXT.mainModalTitle_step2), t && MG_Utils.addClass(t, "active"), o && MG_Utils.addClass(o, "hidden"), s && MG_Utils.removeClass(s, "hidden")) : e.target && MG_Utils.hasClass(e.target, "confirmBtn") && (t = /(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\]|(\[ipv6:)((?:[A-F0-9]{1,4}:){4,}[A-F0-9]{1,4})])/gim, e = a.querySelector(".emailInputErr"), t.test(r.value) ? (MG_Utils.removeClass(r, "errorInput"), e && MG_Utils.addClass(e, "hidden"), "undefined" != typeof confirmNewEmailUrl && MG_Utils.ajaxCall({
                    url: confirmNewEmailUrl,
                    type: "GET",
                    data: {
                        token: token,
                        email: r.value
                    },
                    success: function(e) {
                        var t = l ? l.querySelector("i") : null,
                            a = l ? l.querySelector("span.text") : null;
                        e && e.success ? (t && MG_Utils.addClass(t, "ph-icon-done"), t && MG_Utils.removeClass(t, "ph-icon-error"), a && e.message && (a.innerHTML = e.message), l && MG_Utils.addClass(l, "show"), u && u.closeModal()) : e && !e.success && (t && MG_Utils.removeClass(t, "ph-icon-done"), t && MG_Utils.addClass(t, "ph-icon-error"), a && e.message && (a.innerHTML = e.message), l && MG_Utils.addClass(l, "show"), u) && u.closeModal()
                    }
                })) : (e && MG_Utils.removeClass(e, "hidden"), e && (e.textContent = USER_UPDATE_TEXT.invalid), MG_Utils.addClass(r, "errorInput")))
            }
            t && t.addEventListener("click", c), i && i.addEventListener("click", c), r && r.addEventListener("keyup", e => {
                e = e.target;
                e.value !== e.dataset.original ? i && (i.innerText = USER_UPDATE_TEXT.confirmNewEmail) : i && (i.innerText = USER_UPDATE_TEXT.confirm)
            }), d && d.addEventListener("click", () => {
                l && MG_Utils.removeClass(l, "show")
            })
        })
    }
}();