var VueComponents = function() {
    "use strict";
    return {
        registerFormComponent: function() {
            Vue.customElement("v-create-account-form", {
                props: {
                    orientation: {
                        type: String,
                        default: ""
                    },
                    token: {
                        type: String,
                        required: !0
                    },
                    emailDefault: {
                        type: String,
                        default: ""
                    },
                    usernameDefault: {
                        type: String,
                        default: ""
                    },
                    passwordDefault: {
                        type: String,
                        default: ""
                    },
                    showCaptcha: {
                        type: Number,
                        default: 0
                    },
                    recaptchaKey: {
                        type: String
                    },
                    emailError: {
                        type: String
                    },
                    usernameError: {
                        type: String
                    },
                    passwordError: {
                        type: String
                    },
                    gcaptchaError: {
                        type: String
                    },
                    compareError: {
                        type: String
                    },
                    translation: {
                        type: String
                    },
                    postMessages: {
                        type: String
                    },
                    modal: {
                        type: Boolean,
                        default: !1
                    },
                    checkmarks: {
                        type: Object,
                        default: function() {
                            return {
                                email: "beValidated",
                                username: "beValidated",
                                password: "beValidated"
                            }
                        }
                    },
                    datapageaction: {
                        type: String,
                        default: ""
                    },
                    simplifiedSignup: {
                        type: Number,
                        default: 0
                    },
                    showGoogleSso: {
                        type: Number,
                        default: 0
                    },
                    googleSsoButtonHtml: {
                        type: String,
                        default: ""
                    }
                },
                data: function() {
                    return {
                        validations: {
                            email: {
                                invalid: !0,
                                beValidated: !1,
                                timer: null,
                                inteval: 1e3,
                                validators: [{
                                    errMsg: this.emailError,
                                    pattern: "(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\]|(\\[ipv6:)((?:[A-F0-9]{1,4}:){4,}[A-F0-9]{1,4})])"
                                }]
                            },
                            ...!this.simplifiedSignup && {
                                username: {
                                    invalid: !0,
                                    beValidated: !1,
                                    timer: null,
                                    inteval: 500,
                                    validators: [{
                                        errMsg: this.usernameError,
                                        minlength: 3
                                    }, {
                                        errMsg: this.compareError,
                                        compare: "password"
                                    }]
                                }
                            },
                            password: {
                                invalid: !0,
                                beValidated: !1,
                                timer: null,
                                inteval: 500,
                                validators: this.simplifiedSignup ? [] : [{
                                    errMsg: this.passwordError,
                                    minlength: 8
                                }, {
                                    errMsg: this.compareError,
                                    compare: "username"
                                }]
                            }
                        },
                        validationsgcaptcha: {
                            gcaptcha: {
                                invalid: this.showCaptchaVersion,
                                error: "",
                                validators: [{
                                    errMsg: this.gcaptchaError,
                                    required: this.showCaptchaVersion
                                }]
                            }
                        },
                        email: this.emailDefault,
                        username: this.usernameDefault,
                        password: this.passwordDefault,
                        gcaptcha: "",
                        submitting: !1,
                        errorMessages: [],
                        isFormInvalid: !0,
                        showCaptchaVersion: this.showCaptcha,
                        postErrorsArr: [],
                        checkboxType: checkboxTypeCaptcha,
                        scoreType: scoreTypeCaptcha,
                        dataPageName: this.datapageaction,
                        passTimeout: ""
                    }
                },
                computed: {
                    parseData: function() {
                        return this.translation ? JSON.parse(this.translation) : {}
                    },
                    postErrors: function() {
                        if (this.postErrorsArr) try {
                            var e = JSON.parse(this.postErrorsArr);
                            return e.error || []
                        } catch (e) {
                            console.log(e)
                        }
                        return []
                    }
                },
                mounted: function() {
                    this.modal && "undefined" != typeof phCustomEvent && (a = this, phCustomEvent.subscribe("initSignUp", function(e, t) {
                        !0 === t && a.reset()
                    })), this.postErrorsArr = this.postMessages;
                    var a, e = document.getElementById("js-tasteProfileData"),
                        t = (this.storageAvailable("localStorage") && localStorage.tasteCategories && e && (e.value = localStorage.tasteCategories), ["email", "password"]);
                    this.simplifiedSignup || t.push("username");
                    for (var r = 0; r < t.length; r++) {
                        let s = t[r];
                        this[s].trim() && this.validate(s) && (this.validateAccount(s), setTimeout(function() {
                            var e = new Event("focus"),
                                t = new Event("input"),
                                a = document.querySelector('.js-signUp input[name="' + s + '"]');
                            a && (a.dispatchEvent(e), a.dispatchEvent(t))
                        }, 100))
                    }
                    this.modal || window.dataLayer.push({
                        event: "signup_page_impression"
                    })
                },
                watch: {
                    checkmarks: {
                        handler: function(e) {
                            if ("ph-icon-check" === e.email && "ph-icon-check" === e.password) {
                                if (this.simplifiedSignup) return this.isFormInvalid = !1;
                                if ("ph-icon-check" === e.username) return this.isFormInvalid = !1
                            }
                            this.isFormInvalid = !0
                        },
                        deep: !0
                    }
                },
                methods: {
                    inputIsWrong: function(e) {
                        return "ph-icon-error" === this.checkmarks[e]
                    },
                    prioritizeErrorMessage: function(t) {
                        var e, a = this.errorMessages.findIndex(e => e.name === t); - 1 !== a && (e = this.errorMessages[a], this.errorMessages.splice(a, 1), this.errorMessages.push(e))
                    },
                    removeFromErrorMessages: function(t, e = !1) {
                        this.errorMessages = this.errorMessages.filter(e => e.name !== t), e && (this.checkmarks[t] = "ph-icon-check")
                    },
                    addToErrorMessages: function(t, a) {
                        -1 === this.errorMessages.findIndex(e => e.name === t) ? this.errorMessages.push({
                            name: t,
                            value: a
                        }) : this.errorMessages = this.errorMessages.map(e => e.name === t ? {
                            name: t,
                            value: a
                        } : e), this.checkmarks[t] = "ph-icon-error"
                    },
                    storageAvailable: function(e) {
                        try {
                            var t = window[e],
                                a = "__storage_test__";
                            return t.setItem(a, a), t.removeItem(a), !0
                        } catch (e) {
                            return e instanceof DOMException && (22 === e.code || 1014 === e.code || "QuotaExceededError" === e.name || "NS_ERROR_DOM_QUOTA_REACHED" === e.name) && 0 !== t.length
                        }
                    },
                    validateForm: function() {
                        return void 0 !== this.validations.gcaptcha || !this.showCaptchaVersion || ("undefined" != typeof CaptachaComponents && CaptachaComponents.registerVueComponent(), this.validations.gcaptcha = this.validationsgcaptcha.gcaptcha, !1)
                    },
                    validate: function(e) {
                        if (!e) return !1;
                        for (var t = this[e], a = 0; a < this.validations[e].validators.length; a++) {
                            var s = this.validations[e].validators[a];
                            if (void 0 !== s.minlength && t.length < s.minlength || void 0 !== s.compare && this[s.compare] == t || void 0 !== s.required && s.required && !t || void 0 !== s.pattern && !new RegExp(s.pattern, "gim").test(t)) return this.addToErrorMessages(e, s.errMsg), !1
                        }
                        return !0
                    },
                    onInput: function(e) {
                        var t = e && e.target ? e.target.getAttribute("name") : "",
                            a = (this.validations[t].timer && clearTimeout(this.validations[t].timer), this);
                        this.validations[t].timer = setTimeout(function() {
                            a.validate(t) && ("password" === t ? a.passwordValidation() : a.validateAccount(t))
                        }, this.validations[t].inteval)
                    },
                    onFocus: function(e) {
                        e = e && e.target ? e.target.getAttribute("name") : "";
                        this.prioritizeErrorMessage(e)
                    },
                    formatRequestData: function(e) {
                        var t, a = "";
                        for (t in e) "" != e && (a += "&"), a += t + "=" + encodeURIComponent(e[t]);
                        return a
                    },
                    validateAccount: function(t) {
                        var e = {
                                check_what: t
                            },
                            a = (e[t] = this[t].trim(), "password" === t && (this.simplifiedSignup || (e.username = this.username.trim()), e.email = this.email.trim()), this),
                            s = new XMLHttpRequest;
                        s.onload = function() {
                            var e;
                            200 <= s.status && s.status < 300 && (e = JSON.parse(s.responseText)) && ("" != e.error_message ? (a.addToErrorMessages(t, e.error_message), a.isFormInvalid = !0) : (a.removeFromErrorMessages(t, !0), a.isFormInvalid = !a.validateForm() || !a[t]))
                        }, s.open("POST", this.parseData.checkAccountUrl), s.setRequestHeader("X-Requested-With", "XMLHttpRequest"), s.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8"), s.send(this.formatRequestData(e))
                    },
                    submitForm: function(e) {
                        if (!this.isFormInvalid) {
                            this.submitting = !0;
                            const t = this.$refs.signupForm,
                                a = this;
                            a.modal && !a.showCaptchaVersion ? initializeV3Captcha().then(function() {
                                a.modalSubmitForm()
                            }) : document.getElementById("signup_modal") && "true" == document.getElementById("signup_modal").value ? a.modalSubmitForm() : t.submit(), a.modal ? window.dataLayer.push({
                                event: "signup_complete",
                                location: "liked_videos" === a.dataPageName ? "liked_videos_page_cta" : "show" === a.dataPageName ? "liked_videos_snackbar" : "undefined"
                            }) : window.dataLayer.push({
                                event: "signup_page_complete"
                            }), userSignUpClog(currentDomain, "signup-submitted", originPart, originUrl, clickedElement, newModal)
                        }
                    },
                    modalSubmitForm: function(a = "") {
                        let s = this,
                            e = this.$refs.signupForm,
                            t = Object.fromEntries(new FormData(e));
                        0 < a.length && (t.sso_token = a), s.postErrorsArr = "", delete s.validations.gcaptcha, MG_Utils.ajaxCall({
                            type: "POST",
                            url: s.parseData.createAccountUrl,
                            dataType: "json",
                            data: t,
                            success: function(e) {
                                if (e.success) userSignUpClog(currentDomain, "signup-approval", originPart, originUrl, clickedElement, newModal), e.redirectUrl ? window.location.href = e.redirectUrl : e.redirect ? window.location.href = e.redirect : document.location.reload();
                                else {
                                    var t;
                                    if (e.twoStepVerification) return signinbox.show(), (t = signinbox.container.querySelector(".js-loginForm")) ? (MG_Utils.addClass(t, "displayNone"), void signinbox.setupTwoStepVerification(e)) : void 0;
                                    document.getElementById("g-recaptcha-response") && "undefined" != typeof grecaptcha && grecaptcha.enterprise.reset(), a.length <= 0 && (s.showCaptchaVersion = e.showCaptchaV2 ? 1 : 0), e.userNotices ? (s.errorMessages = [], s.addToErrorMessages("", e.userNotices.error ? e.userNotices.error[0] : "")) : e.message && (s.errorMessages = [], s.addToErrorMessages("", e.message)), s.isFormInvalid = !s.validateForm()
                                }
                            },
                            error: function(e) {
                                e.userNotices && (s.postErrorsArr = JSON.stringify(e.userNotices))
                            }
                        })
                    },
                    onCaptchaVerified: function(e) {
                        this.gcaptcha = e && e.detail ? e.detail[0] : "", this.validate("gcaptcha") ? (this.removeFromErrorMessages("gcaptcha", !0), this.isFormInvalid = !this.validateForm(), this.modal && (this.submitting = !1)) : this.addToErrorMessages("gcaptcha", this.validations.gcaptcha.error)
                    },
                    onCaptchaExpired: function() {
                        this.gcaptcha = "", this.validations.gcaptcha.invalid = !0, this.addToErrorMessages("gcaptcha", this.parseData.gcaptchaExpired), this.isFormInvalid = !0
                    },
                    reset: function() {
                        Object.assign(this.$data, this.$options.data.apply(this))
                    },
                    passwordValidation: function() {
                        const t = this;
                        let e = this.modal ? document.querySelector(".js-signUpFormModal") : document.querySelector(".js-signUpFormContainer"),
                            a = e.querySelector("#createEmail"),
                            s = e.querySelector("#createUsername"),
                            r = e.querySelector("#originalPassword"),
                            i = e.querySelector("#strengthValue");
                        if ("" === r.value) t.removeFromErrorMessages("password", !0);
                        else {
                            clearTimeout(t.passTimeout);
                            let e = {
                                password: r.value,
                                email: a.value
                            };
                            t.simplifiedSignup || (e.username = s.value), t.passTimeout = setTimeout(function() {
                                MG_Utils.ajaxCall({
                                    url: t.parseData.checkPasswordUrl,
                                    data: e,
                                    type: "POST",
                                    success: function(e) {
                                        i.removeAttribute("class"), i && (i.innerHTML = e.strengthMessage), 1 === e.strengthScore ? MG_Utils.addClass(i, "strWeak") : 2 === e.strengthScore ? MG_Utils.addClass(i, "strFair") : 3 === e.strengthScore ? MG_Utils.addClass(i, "strStrong") : 4 === e.strengthScore && MG_Utils.addClass(i, "strVeryStrong"), "" != e.error ? t.addToErrorMessages("password", e.error) : t.removeFromErrorMessages("password", !0)
                                    }
                                })
                            }, 500)
                        }
                    },
                    passwordVisibility: function() {
                        var e = document.querySelector(".signUpPassIcon"),
                            t = document.querySelector(".signUpPasswordWrapper #originalPassword");
                        e.classList.contains("ph-icon-view-on") ? (e.classList.remove("ph-icon-view-on"), e.classList.add("ph-icon-view-off"), t.type = "password") : (e.classList.add("ph-icon-view-on"), e.classList.remove("ph-icon-view-off"), t.type = "text")
                    },
                    initGoogleSso: function() {
                        var e = document.getElementsByTagName("head")[0],
                            t = document.createElement("script"),
                            a = (t.type = "text/javascript", t.src = "https://accounts.google.com/gsi/client", e.appendChild(t), this);
                        a.errorMessages = [], t.onload = function() {
                            google.accounts.oauth2.initTokenClient({
                                client_id: gSSOClientId,
                                scope: "https://www.googleapis.com/auth/userinfo.email",
                                ux_mode: "popup",
                                callback: e => {
                                    document.getElementById("signup_modal") && "true" == document.getElementById("signup_modal").value ? initializeV3Captcha().then(function() {
                                        a.modalSubmitForm(e.access_token)
                                    }) : a.modalSubmitForm(e.access_token)
                                }
                            }).requestAccessToken()
                        }
                    }
                },
                template: '<form autocomplete="off" method="post" :action="parseData.createAccountUrl" ref="signupForm" class="js-signUp"><input type="hidden" name="token" :value="token" /><input type="hidden" name="orientation" value="gay" v-if="orientation==\'gay\'" /><input type="hidden" name="redirect" :value="parseData.redirectUrl" /><input type="hidden" name="taste_profile" id="js-tasteProfileData" /><input type="hidden" name="show_onboarding" class="show_onboarding" value="" /><input v-if="modal" type="hidden" class="js_captcha_token" name="g-recaptcha-response" id="captcha_token" value=""><input v-else type="hidden" name="g-recaptcha-response" id="captcha_token" value=""><input type="hidden" id="captcha_type" name="captcha_type" :value="showCaptchaVersion ? checkboxType : scoreType"><input v-if="modal" type="hidden" id="signup_modal" name="signup_modal" value="true"><section class="formStepOne"><div id="errors" v-if="errorMessages.length > 0" class="shown" v-html="errorMessages[errorMessages.length-1].value"></div><div id="postErrors" v-show="postErrors.length" class="shown">{{postErrors[0]}}</div><input id="createEmail" type="text" name="email" v-model.trim="email" :class="{\'wrong\': inputIsWrong(\'email\')}" @input="onInput" @focus="onFocus" :placeholder="parseData.emailHolder" maxlength="254" autofocus><span :class="this.checkmarks[\'email\']"></span><input v-if="!simplifiedSignup" id="createUsername" type="text" name="username" v-model.trim="username" @input="onInput" @focus="onFocus" :class="{\'wrong\': inputIsWrong(\'username\')}" :placeholder="parseData.usernameHolder" maxlength="18"><span v-if="!simplifiedSignup" :class="this.checkmarks[\'username\']"></span><div class="signUpPasswordWrapper"><input id="originalPassword" autocomplete="off" type="password" name="password" v-model.trim="password" @focus="onFocus" @input="onInput" :class="{\'wrong\': inputIsWrong(\'password\')}" :placeholder="parseData.passwordHolder" maxlength="40"><div class="signUpPasswordIconsWrapper"><span data-visiblitily="originalPassword" class="signUpPassIcon icons ph-icon-view-off" @click="passwordVisibility"></span><span :class="this.checkmarks[\'password\']"></span></div></div><div class="strengthWrap">{{parseData.passStrength}} <span id="strengthValue"></span></div><section class="optional" v-if="showCaptchaVersion"><p class="security"></p><v-recaptcha :loadscript="true" name="gcaptcha" :type="checkboxType" :showCaptcha="showCaptchaVersion" @verify="onCaptchaVerified" @expired="onCaptchaExpired" :sitekey="recaptchaKey"></v-recaptcha></section><input type="submit" id="js-signUpBtn" class="buttonBase orangeButton big" :value="parseData.submitLabel" :disabled="isFormInvalid || submitting" @click="submitForm"><button class="gsi-material-button" id="ssoGoogleSignupButton" type="button" v-if="showGoogleSso && modal" v-html="googleSsoButtonHtml" @click="initGoogleSso"></button><div v-if="modal" class="haveAccount">{{parseData.loginText1}} <a href="javascript:signinbox.show();">{{parseData.loginText2}}</a> {{parseData.loginText3}}</div><span v-else class="loginLink">{{parseData.or}} <a href="javascript:signinbox.show();">{{parseData.signin}}</a></span><button class="gsi-material-button" id="ssoGoogleSignupButton" type="button" v-if="showGoogleSso && modal  === false" v-html="googleSsoButtonHtml" @click="initGoogleSso"></button><p class="options" v-html="parseData.terms"></p><p class="options"><a :href="parseData.resendConfirmationUrl">{{parseData.resend}}</a></p></section></form>'
            })
        }
    }
}();
! function() {
    VueComponents.registerFormComponent();
    const t = () => {
        document.querySelectorAll(".show_onboarding").forEach(e => {
            e.setAttribute("value", "1")
        })
    };
    setTimeout(() => {
        var e = document.querySelectorAll(".js_hasOnboardingLoginBtn");
        e && e.forEach(function(e) {
            e.addEventListener("click", () => {
                t()
            })
        }), "undefined" != typeof onSignupPageFlag && "true" === onSignupPageFlag && t()
    }, "1000")
}();