class OnboardingFlowModal {
    constructor() {
        let n = 0,
            t = null,
            a = !1,
            r = !0;
        const o = new Event("onboardingFinished"),
            s = this,
            i = {
                declineOnBoardingProcessBtn: "js_decline-btn",
                acceptOnBoardingProcessBtn: "js_goToOnboardingModal",
                backToCustomizeBtn: "js_backToCustomizeBtn",
                welcomeModalPopUp: "welcome-onboardinModal",
                exitConfirmModalPopUp: "exit-onboardingModal",
                onboardingStepsModalPopUp: "steps-onboardingModal",
                completedOnboardingModalPopUp: "completed-onboardingModal",
                stepOne: "stepOne",
                closeModalBtn: ".js_closeModalBtn",
                stepModal: "stepsModal",
                nextButton: ".js_nextStep",
                stepOneBtn: "js_stepOneBtn",
                stepTwoBtn: "js_stepTwoBtn",
                prevButton: ".js_backToPrevStep",
                nextButtonInactive: ".inactive-btn",
                errorDOFBtn: ".error-DOFBtn",
                doneAllStepsBtn: "js_doneAllSteps",
                closeAllModalsBtn: ".js_closeAllModals",
                subscribeBtn: ".js_subscribeBtn",
                selectAllPill: ".selectAll-pill",
                modalBackgroundOverlay: ".modalBackgroundOverlay",
                basicInformationBday: document.getElementById("js_basicInformationBday"),
                basicInformationOrientation: document.getElementById("js_basicInformationOrientation"),
                day: document.getElementById("js_day"),
                month: document.getElementById("js_month"),
                year: document.getElementById("js_year"),
                country: document.getElementById("js_country"),
                orientation: document.getElementById("js_orientation"),
                errorMsg_1: document.getElementById("js_errorMsg_1"),
                errorMsg_2: document.getElementById("js_errorMsg_2"),
                errorMsg_3: document.getElementById("js_errorMsg_3"),
                emailVerificationBanner: document.querySelector(".js-emailBannerOnboarding"),
                changeUserNameInput: document.getElementById("js_changeYourUserNameInput"),
                responseMsgWrapper: document.getElementById("js_responseMsg"),
                userProfileDataUserName: document.querySelector(".js_userName"),
                exitOnboardingConfirmBtn: "js_confirmExitBtn",
                today: new Date
            };
        s.init = function() {
            s.initGtmEvent("quiz_start"), s.attachEvents(), document.getElementById(i.stepTwoBtn) && s.showEthnicityAndCategory("women"), userSignUpClog(currentDomain, "onb-flow", originPart, originUrl, clickedElement, newModal)
        }, s.gtmHandleButtons = e => {
            var t = document.getElementById(i.exitOnboardingConfirmBtn),
                n = document.getElementById(i.backToCustomizeBtn),
                a = document.querySelector("." + i.onboardingStepsModalPopUp);
            MG_Utils.hasClass(a, "is-hidden") || (t.dataset.label = "abandon_yes_" + (e + 1), n.dataset.label = "abandon_continue_" + (e + 1))
        }, s.initGtmEvent = function(e) {
            window.dataLayer.push({
                event: "welcome_quiz",
                event_label: e
            })
        }, s.attachEvents = function() {
            window.addEventListener("beforeunload", e => {
                if (a) return e.preventDefault(), e.returnValue = !0
            }), document.getElementById(i.declineOnBoardingProcessBtn).addEventListener("click", e => {
                s.openExitConfirmationPopup(), userSignUpClog(currentDomain, "onb-flow-abandon", originPart, originUrl, "later", newModal)
            }), document.getElementById(i.acceptOnBoardingProcessBtn).addEventListener("click", e => {
                s.openStepsPopUpModals(), userSignUpClog(currentDomain, "onb-flow-proceed", originPart, originUrl, "lets-do-it", newModal)
            }), document.querySelectorAll(i.closeModalBtn).forEach(e => {
                e.addEventListener("click", e => {
                    s.openExitConfirmationPopup(), userSignUpClog(currentDomain, "onb-flow-abandon", originPart, originUrl, "button-close-x", newModal)
                })
            }), document.querySelectorAll(i.modalBackgroundOverlay).forEach(e => {
                let t = "";
                e.addEventListener("click", e => {
                    e = e.target || e.srcElement;
                    MG_Utils.hasClass(e, "modalBackgroundOverlay") && (s.openExitConfirmationPopup(), t = MG_Utils.hasClass(e, "is-hidden") && !MG_Utils.hasClass(e, "welcome-onboardinModal") ? "quit_outside_modal_" + (n + 1) : MG_Utils.hasClass(e, "completed-onboardingModal") ? "quit_outside_modal_complete" : "quit_outside_modal_" + n, s.initGtmEvent(t), userSignUpClog(currentDomain, "onb-flow-abandon", originPart, originUrl, "outside_modal_window", newModal)), MG_Utils.hasClass(e, "completed-onboardingModal") && s.completedCloseAllModals()
                })
            }), document.getElementById(i.backToCustomizeBtn).addEventListener("click", e => {
                s.openStepsPopUpModals()
            }), document.getElementById(i.exitOnboardingConfirmBtn).addEventListener("click", () => {
                s.abandonOnboardingAjaxCall(), userSignUpClog(currentDomain, "onb-flow-confirm-abandon", originPart, originUrl, "yes", newModal), document.dispatchEvent(o)
            }), document.querySelectorAll(i.nextButton).forEach(t => {
                t.addEventListener("click", e => {
                    t.classList.contains("disabled-nextBtn") || t.classList.contains("inactive-btn") || t.classList.contains("error-DOFBtn") || s.nextBtn()
                })
            }), document.getElementById(i.stepOneBtn).addEventListener("click", e => {
                document.querySelector(i.nextButtonInactive) || document.querySelector(i.errorDOFBtn) ? s.initGtmEvent("step_1_next_error") : s.stepOneAjaxCall()
            }), document.getElementById(i.stepTwoBtn) && document.getElementById(i.stepTwoBtn).addEventListener("click", e => {
                s.stepTwoAjaxCall()
            }), document.querySelectorAll(i.subscribeBtn).forEach(e => {
                e.addEventListener("click", e => {
                    var e = e.target,
                        t = e.parentNode.classList.contains("buttonSubscribe") ? e.parentNode.getAttribute("data-subscribe-url") : e.parentNode.getAttribute("data-unsubscribe-url"),
                        n = {
                            type: e.parentNode.getAttribute("data-type"),
                            id: e.parentNode.getAttribute("data-id")
                        };
                    s.stepThreeAjaxCall(t, n, e)
                })
            }), document.querySelectorAll(i.prevButton).forEach(e => {
                e.addEventListener("click", e => {
                    s.prevBtn()
                })
            }), document.getElementById(i.doneAllStepsBtn).addEventListener("click", e => {
                s.initGtmEvent("quiz_complete"), s.completeOnboardingAjaxCall(), s.openCompletedOnboardingPopUp(), userSignUpClog(currentDomain, "onb-flow-sub", originPart, originUrl, "done", newModal)
            }), document.querySelectorAll(i.closeAllModalsBtn).forEach(e => {
                e.addEventListener("click", e => {
                    s.completedCloseAllModals(), document.dispatchEvent(o)
                })
            }), [i.year, i.month, i.day, i.orientation].forEach(e => {
                e.addEventListener("change", e => {
                    s.activateStepOneBtn(), s.ageChecker()
                })
            }), [i.year, i.month, i.day, i.country, i.orientation].forEach(e => {
                e.addEventListener("change", e => {
                    document.querySelectorAll(i.nextButton).forEach(e => {
                        e.classList.remove("disabled-nextBtn")
                    })
                })
            }), document.getElementById("js_orientation").addEventListener("change", e => {
                var t = e.target.value.split("|")[0],
                    e = e.target.value.split("|")[1];
                switch (s.initGtmEvent(e), t) {
                    case "2":
                    case "7":
                        s.showSubscriptionsRow("women");
                        break;
                    case "1":
                        s.showSubscriptionsRow("men");
                        break;
                    case "3":
                    case "6":
                        s.showSubscriptionsRow("trans");
                        break;
                    default:
                        s.showSubscriptionsRow("women")
                }
            }), document.querySelector(i.nextButtonInactive).addEventListener("click", e => {
                e.target.classList.contains("disabled-nextBtn") || s.validateBasicInformation()
            }), document.getElementById(i.stepTwoBtn) && (document.getElementById("preference_women").addEventListener("click", e => {
                s.showEthnicityAndCategory("women")
            }), document.getElementById("preference_men").addEventListener("click", e => {
                s.showEthnicityAndCategory("men")
            }), document.getElementById("preference_trans").addEventListener("click", e => {
                s.showEthnicityAndCategory("trans")
            }), document.querySelector(".interestedToWrapper").addEventListener("change", e => {
                e = e.target;
                t !== e && (s.clearCheckBoxes(), t = e)
            }), document.querySelectorAll(i.selectAllPill).forEach(e => {
                e.addEventListener("click", e => {
                    var e = e.target,
                        t = e.parentNode.getAttribute("data-id");
                    s.checkAllEthnicities(e, t)
                })
            })), document.getElementById("js_changeYourUserName") && (i.changeUserNameInput.addEventListener("input", () => {
                s.changeUserNameAjaxCall()
            }), i.changeUserNameInput.addEventListener("blur", () => {
                currentDeviceType && "isMobileDevice" === currentDeviceType && setTimeout(function() {
                    window.scrollTo({
                        top: 0,
                        behavior: "smooth"
                    })
                }, 0)
            }))
        }, s.openExitConfirmationPopup = () => {
            s.gtmHandleButtons(n), document.querySelector("." + i.welcomeModalPopUp).classList.add("is-hidden"), document.querySelector("." + i.exitConfirmModalPopUp).classList.remove("is-hidden"), document.querySelector("." + i.onboardingStepsModalPopUp).classList.add("is-hidden"), a = !1, s.adjustEmailBannerPosition(!0, i.exitConfirmModalPopUp, 0)
        }, s.openStepsPopUpModals = () => {
            document.querySelector("." + i.welcomeModalPopUp).classList.add("is-hidden"), document.querySelector("." + i.exitConfirmModalPopUp).classList.add("is-hidden"), document.querySelector("." + i.onboardingStepsModalPopUp).classList.remove("is-hidden"), s.updateStepDisplay(n), a = !0
        }, s.adjustEmailBannerPosition = (e, t, n) => {
            var a;
            i.emailVerificationBanner && ((a = i.emailVerificationBanner).style.top = "0px", MG_Utils.removeClass(a, "behindModal"), e) && t && void 0 !== n && (e = (t = (e = document.querySelector("." + t)) && e.children[n]).offsetTop - (a.offsetHeight + a.offsetTop), t.offsetTop < a.offsetHeight ? MG_Utils.addClass(a, "behindModal") : e < 0 && (a.style.top = e + "px"))
        }, s.openCompletedOnboardingPopUp = () => {
            document.querySelector("." + i.completedOnboardingModalPopUp).classList.remove("is-hidden"), document.querySelector("." + i.onboardingStepsModalPopUp).classList.add("is-hidden"), a = !1
        }, s.updateStepDisplay = n => {
            document.querySelectorAll("." + i.stepModal).forEach((e, t) => {
                e.style.display = t === n ? "block" : "none"
            }), s.adjustEmailBannerPosition(!0, i.onboardingStepsModalPopUp, n)
        }, s.nextBtn = () => {
            n < document.querySelectorAll("." + i.stepModal).length - 1 && (n++, s.updateStepDisplay(n))
        }, s.prevBtn = () => {
            0 < n && (n--, s.updateStepDisplay(n))
        }, s.stepOneAjaxCall = () => {
            var e = i.year.value || "",
                t = i.month.value || "",
                n = i.day.value || "",
                a = i.country.value || "",
                o = i.orientation.value || "",
                s = i.changeUserNameInput && i.changeUserNameInput.value ? i.changeUserNameInput.value : "",
                e = {
                    year: e,
                    month: t,
                    day: n,
                    country: a,
                    preference: o.split("|")[0],
                    username: s,
                    token: token
                };
            MG_Utils.ajaxCall({
                url: "/onboarding/stepOne",
                type: "POST",
                data: e,
                dataType: "json",
                success: function() {
                    i.changeUserNameInput && currentUserName !== i.changeUserNameInput.value && (i.changeUserNameInput.disabled = !0, i.responseMsgWrapper.innerHTML = userNameChangeMsg, i.responseMsgWrapper.classList.add("unavailableUserName"), i.responseMsgWrapper.classList.remove("availableUserName"), i.userProfileDataUserName.innerHTML = i.changeUserNameInput.value)
                }
            })
        }, s.stepTwoAjaxCall = () => {
            var e = document.querySelector('input[name="preference"]:checked').value.toLowerCase(),
                t = Array.from(document.querySelectorAll('input[name="ethnicities[]"]:checked')).map(e => e.value),
                n = Array.from(document.querySelectorAll('input[name="categories[]"]:checked')).map(e => e.value),
                e = {
                    preference: e,
                    ethnicities: JSON.stringify(t),
                    categories: JSON.stringify(n),
                    token: token
                };
            MG_Utils.ajaxCall({
                url: "/onboarding/stepTwo",
                type: "POST",
                data: e,
                dataType: "json",
                success: function() {}
            })
        }, s.stepThreeAjaxCall = (e, t, n) => {
            MG_Utils.ajaxCall({
                url: e,
                type: "POST",
                data: t,
                dataType: "json",
                success: function(e) {
                    "buttonUnsubscribe" == e.class ? (n.parentNode.classList.add("buttonUnsubscribe"), n.parentNode.classList.remove("buttonSubscribe"), n.classList.remove("ph-icon-add-box"), n.classList.add("ph-icon-check-square")) : (n.parentNode.classList.add("buttonSubscribe"), n.parentNode.classList.remove("buttonUnsubscribe"), n.classList.remove("ph-icon-check-square"), n.classList.add("ph-icon-add-box"))
                }
            })
        }, s.completeOnboardingAjaxCall = () => {
            var e = {
                token: token
            };
            MG_Utils.ajaxCall({
                url: "/onboarding/completed",
                type: "POST",
                data: e,
                dataType: "json",
                success: function() {}
            })
        }, s.abandonOnboardingAjaxCall = () => {
            var e = {
                token: token
            };
            MG_Utils.ajaxCall({
                url: "/onboarding/abandoned",
                type: "POST",
                data: e,
                dataType: "json",
                success: function() {}
            })
        }, s.completedCloseAllModals = () => {
            document.querySelector("." + i.welcomeModalPopUp).classList.add("is-hidden"), document.querySelector("." + i.exitConfirmModalPopUp).classList.add("is-hidden"), document.querySelector("." + i.onboardingStepsModalPopUp).classList.add("is-hidden"), document.querySelector("." + i.completedOnboardingModalPopUp).classList.add("is-hidden"), document.body.style.overflow = "revert-layer", document.getElementById("header") && (document.getElementById("header").style.zIndex = "2", document.getElementById("headerMenuContainer").style.zIndex = "3"), a = !1, s.adjustEmailBannerPosition(!1);
            var e = document.querySelector(".emailVerHomepageContainer");
            e && MG_Utils.removeClass(e, "onboarding")
        }, s.validateBasicInformation = () => {
            var e = "" !== i.year.value && "" !== i.month.value && "" !== i.day.value,
                t = "" !== i.orientation.value,
                n = parseInt(i.year.value),
                a = parseInt(i.month.value),
                o = parseInt(i.day.value),
                s = new Date(i.today.getFullYear() - 18, i.today.getMonth(), i.today.getDate()),
                n = new Date(n, a - 1, o);
            switch (!0) {
                case !e && !t:
                    i.errorMsg_1.classList.add("is-hidden"), i.errorMsg_2.classList.remove("is-hidden"), i.errorMsg_3.classList.add("is-hidden"), i.basicInformationBday.classList.add("notSelected"), i.basicInformationOrientation.classList.add("notSelected");
                    break;
                case e && !t:
                    i.errorMsg_1.classList.remove("is-hidden"), i.errorMsg_2.classList.add("is-hidden"), i.errorMsg_3.classList.add("is-hidden"), i.basicInformationOrientation.classList.add("notSelected"), i.basicInformationBday.classList.remove("notSelected");
                    break;
                case !e && t:
                    i.errorMsg_1.classList.remove("is-hidden"), i.errorMsg_2.classList.add("is-hidden"), i.errorMsg_3.classList.add("is-hidden"), i.basicInformationBday.classList.add("notSelected"), i.basicInformationOrientation.classList.remove("notSelected");
                    break;
                case n > i.today || s < n:
                    i.errorMsg_1.classList.add("is-hidden"), i.errorMsg_2.classList.add("is-hidden"), i.errorMsg_3.classList.remove("is-hidden"), i.basicInformationBday.classList.add("notSelected"), i.basicInformationOrientation.classList.remove("notSelected");
                    break;
                default:
                    i.errorMsg_1.classList.add("is-hidden"), i.errorMsg_2.classList.add("is-hidden"), i.errorMsg_3.classList.add("is-hidden"), i.basicInformationBday.classList.remove("notSelected"), i.basicInformationOrientation.classList.remove("notSelected"), document.querySelectorAll(i.nextButton).forEach(e => {
                        1 == r && e.classList.remove("inactive-btn")
                    })
            }
        }, s.activateStepOneBtn = () => {
            var e = "" !== i.year.value && "" !== i.month.value && "" !== i.day.value,
                t = "" !== i.orientation.value;
            switch (!0) {
                case e && t && 1 == r:
                    document.querySelectorAll(i.nextButton).forEach(e => {
                        e.classList.remove("inactive-btn")
                    }), i.errorMsg_1.classList.add("is-hidden"), i.errorMsg_2.classList.add("is-hidden"), i.basicInformationBday.classList.remove("notSelected"), i.basicInformationOrientation.classList.remove("notSelected");
                    break;
                case e:
                    i.basicInformationBday.classList.remove("notSelected");
                    break;
                case t:
                    i.basicInformationOrientation.classList.remove("notSelected")
            }
        }, document.getElementById(i.stepTwoBtn) && (s.showEthnicityAndCategory = e => {
            document.querySelectorAll(".ethnicity-wrapper, .category-wrapper").forEach(e => {
                e.style.display = "none"
            }), document.getElementById("ethnicity-" + e).style.display = "block", document.getElementById("category-" + e).style.display = "block"
        }, s.clearCheckBoxes = () => {
            document.querySelectorAll(".js_ethnicitySwitch, .js_categoriesSwitch").forEach(e => {
                e.checked = !1
            })
        }, s.checkAllEthnicities = (t, e) => {
            document.querySelectorAll(".js_ethnicitySwitch-" + e).forEach(e => {
                t.checked ? e.checked = !0 : e.checked = !1, e.addEventListener("click", () => {
                    t.checked = !1
                })
            })
        }), s.showSubscriptionsRow = e => {
            document.querySelectorAll(".subscription-wrapper").forEach(e => {
                e.style.display = "none"
            });
            var t = currentDeviceType && "isDesktopDevice" === currentDeviceType ? "block" : "flex";
            document.getElementById("subscription-" + e).style.display = t
        }, s.ageChecker = () => {
            var e = parseInt(i.year.value),
                t = parseInt(i.month.value),
                n = parseInt(i.day.value),
                a = new Date(i.today.getFullYear() - 18, i.today.getMonth(), i.today.getDate()),
                e = new Date(e, t - 1, n);
            e > i.today || a < e ? (document.querySelectorAll(i.nextButton).forEach(e => {
                e.classList.add("error-DOFBtn")
            }), i.errorMsg_1.classList.add("is-hidden"), i.errorMsg_2.classList.add("is-hidden"), i.errorMsg_3.classList.remove("is-hidden"), i.basicInformationBday.classList.add("notSelected"), i.basicInformationOrientation.classList.remove("notSelected")) : (document.querySelectorAll(i.nextButton).forEach(e => {
                e.classList.remove("error-DOFBtn")
            }), i.errorMsg_3.classList.add("is-hidden"))
        }, s.changeUserNameAjaxCall = () => {
            const t = "" !== i.year.value && "" !== i.month.value && "" !== i.day.value,
                n = "" !== i.orientation.value,
                e = i.changeUserNameInput.value,
                a = {
                    username: e,
                    token: token
                };
            MG_Utils.ajaxCall({
                url: "/onboarding/checkUserName",
                type: "POST",
                data: a,
                dataType: "json",
                success: function(e) {
                    i.changeUserNameInput.classList.add("ajaxChangeUserNameInput"), i.responseMsgWrapper.classList.remove("is-hidden"), !0 === e.status ? (i.responseMsgWrapper.innerHTML = e.message, i.responseMsgWrapper.classList.add("availableUserName"), i.responseMsgWrapper.classList.remove("unavailableUserName"), r = !0, t && n && document.getElementById(i.stepOneBtn).classList.remove("inactive-btn")) : (i.responseMsgWrapper.innerHTML = e.error, i.responseMsgWrapper.classList.add("unavailableUserName"), i.responseMsgWrapper.classList.remove("availableUserName"), document.getElementById(i.stepOneBtn).classList.add("inactive-btn"), r = !1)
                }
            })
        }
    }
}
if (document.getElementById("onboardingInformation")) {
    document.body.style.overflow = "hidden", document.getElementById("header") && (document.getElementById("header").style.zIndex = "0", document.getElementById("headerMenuContainer").style.zIndex = "0");
    try {
        (onboardingModalFlow = new OnboardingFlowModal).init()
    } catch (e) {
        console.log(e)
    }
    const j0 = document.querySelectorAll(".js_mobileContainer");
    "undefined" != typeof MG_Scroll && MG_Scroll.init({
        width: "auto",
        selector: j0,
        height: "100%",
        color: "#FF9000",
        size: "3px",
        alwaysVisible: !0,
        railVisible: !0,
        railOpacity: 1,
        railColor: "transparent",
        distance: "2px",
        opacity: 1,
        railClass: "track3",
        barClass: "handle3",
        wrapperClass: "wrapper3",
        wheelStep: 5,
        enLargeOnHover: !0,
        enLargedSize: "4px"
    })
}