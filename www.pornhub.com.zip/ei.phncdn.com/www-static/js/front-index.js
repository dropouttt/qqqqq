let RecentlyFeaturedObserver = function() {
    let t;

    function n(e) {
        t && t.unobserve(e)
    }
    return {
        init: function() {
            "IntersectionObserver" in window && (t = new IntersectionObserver(function(e) {
                e.forEach(function(e) {
                    e.isIntersecting && "undefined" != typeof ga && (e = document.getElementById("mostRecentVideosSection"), ga("send", "event", "Homepage", "impression", "Viewed RF", {
                        nonInteraction: !0
                    }), e) && n(e)
                })
            }, {
                root: null,
                rootMargin: "0px",
                threshold: 0
            }))
        },
        isObserverSet: function() {
            return void 0 !== t
        },
        subscribe: function(e) {
            t && t.observe(e)
        },
        unsubscribe: n
    }
}();
MG_Utils.domReady(function() {
    var e = document.querySelector("li.sniperModeEngaged iframe"),
        t = document.querySelector("li.emptyBlockSpace"),
        e = (!e && t && (t.style.display = "block"), document.querySelector(".logoFooterWrapper")),
        n = ("undefined" != typeof FRONT_INDEX && e && FRONT_INDEX.isPremium && MG_Utils.addClass(e, "premiumFooter"), "undefined" != typeof SEARCH_ENGINE_DATA && document.addEventListener("click", function(e) {
            var a = e.target,
                t = a && a.parentNode;
            if (a && (MG_Utils.hasClass(a, "js-linkVideoThumb") || MG_Utils.hasClass(a, "thumbnailTitle")) || t && MG_Utils.hasClass(t, "title")) {
                var t = MG_Utils.closest(a, ".videoblock"),
                    n = MG_Utils.closest(a, "ul.videos"),
                    t = t && MG_Utils.getData(t, "video-vkey"),
                    n = n && n.id,
                    i = "";
                if (t && SEARCH_ENGINE_DATA.newDimension51 && (e.preventDefault(), i = "#singleFeedSection" === n ? SEARCH_ENGINE_DATA.newDimension51.replace("<Section>", 23) : SEARCH_ENGINE_DATA.newDimension51.replace("<Section>", 24)), i && Etahub.setCookie(t, i), "A" === a.tagName && (MG_Utils.hasClass(a, "js-linkVideoThumb") || MG_Utils.hasClass(a, "thumbnailTitle"))) {
                    let t = 0,
                        n = void 0 !== a.dataset ? a.dataset.videoId : 0,
                        i = document.querySelectorAll("#singleFeedSection .pcVideoListItem"),
                        e = MG_Utils.closest(a, "li.videoblock"),
                        s = e && e.dataset ? e.dataset.eventLabel : null;
                    if (n) {
                        for (let e = 0; e < i.length; e++)
                            if (i[e].id === "v" + n) {
                                t = e + 1;
                                break
                            }
                        phubGenericFuncModule.sendGAEvent("Homepage", "homepage thumbnail - pos " + t, .01)
                    }
                    s && phubGenericFuncModule.sendGAEvent("Homepage", s, 1)
                }
                "_blank" === a.target ? window.open(a.href) : window.location.href = a.href
            }
        }), document.querySelectorAll("[data-hpBlockName]"));
    for (let e = 0; e < n.length; e++) n[e] && n[e].addEventListener("click", function(e) {
        var t = e.target,
            e = e.currentTarget,
            e = e ? e.dataset.hpblockname : "",
            n = t && t.parentNode;
        t && "A" === t.tagName && n && (MG_Utils.hasClass(t, "sectionTitleLink") || MG_Utils.hasClass(t, "js-linkVideoThumb") || MG_Utils.hasClass(n, "title") || MG_Utils.hasClass(n, "trendingNow")) && (MG_Utils.hasClass(n, "trendingNow") ? phubGenericFuncModule.sendGAEvent("Homepage", e, 1) : phubGenericFuncModule.sendGAEvent("Homepage", e))
    });
    const i = document.querySelector(".scrollableWrapper"),
        s = document.querySelector(".trendingNowWrapper"),
        a = document.querySelector(".leftArrowWrapper"),
        l = document.querySelector(".rightArrowWrapper");
    var o, r = 0;

    function d() {
        o = i && s ? s.clientWidth - i.clientWidth : 0
    }

    function c(e) {
        return Math.min(Math.max(e, 0), o)
    }

    function u() {
        s && (0 === r ? a && MG_Utils.addClass(a, "hide") : a && MG_Utils.removeClass(a, "hide"), r === o ? l && MG_Utils.addClass(l, "hide") : l && MG_Utils.removeClass(l, "hide"))
    }
    window.addEventListener("resize", d), d(), s && s.addEventListener("wheel", e => {
        e.preventDefault(), r = c(r += Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY), s.style.webkitTransform = "translateX(-" + r + "px)", s.style.transform = "translateX(-" + r + "px)", u()
    }), a && a.addEventListener("click", function() {
        s && (r = c(r -= 200), s.style.webkitTransform = "translateX(-" + r + "px)", s.style.transform = "translateX(-" + r + "px)", u())
    }), l && l.addEventListener("click", function() {
        s && (r = c(r += 200), s.style.webkitTransform = "translateX(-" + r + "px)", s.style.transform = "translateX(-" + r + "px)", u())
    })
});