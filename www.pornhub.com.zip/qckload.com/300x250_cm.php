<!DOCTYPE html>

<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Watch Now</title>
<style>
	* {
	  margin: 0;
	  padding: 0;
	  -webkit-box-sizing: border-box;
	  -moz-box-sizing: border-box;
	  box-sizing: border-box;
	}
	img {
	  border: none;
	  display: block;
	}
	a {
	  text-decoration: none;
	}
	body,
	html {
	  width: 100%;
	  height: 100%;
	  min-height: 100%;
	  background: #000000;
	  font-family: Arial, sans-serif;
	}
	#aUrl{

	}
	#videoUrl{
		position:relative;
    	z-index:0;
	}
	.overlay {
		position:absolute;
		top:0;
		left:0;
		z-index:1;
	}
	
	.container {
		position:relative;
		width: 300px;
    	height: 250px;
	}
	.container video {
		position:relative;
		z-index:0;
	}
	.headline{
		position:absolute;
		top:5px;
		left:0;
		z-index:1;
		text-align: center;
		color: #FFFFFF;
		font-size: 18px;
		
		text-shadow: 0px 0px 20px #000000, 0px 0px 20px #000000;
		text-decoration: none;
		line-height: 1.1;
		padding-left: 55px;
		padding-right: 10px;
	}
	.cta{
		position:absolute;
		max-width: 300px;
		max-height: 250px;
		width: 300px;
		height: 250px;
		top:220px;
		left:0;
		z-index:1;
		text-align: center;
		color: #FFFFFF;
		font-size: 20px;
		
		text-shadow: 0px 0px 20px #000000, 0px 0px 20px #000000;
		text-decoration: underline;
		line-height: 1.1;
	}
	.live-text {
		position: absolute;
		top: 0;
		left: 0;
		background-color: red;
		color: white;
		padding: 5px;
		font-weight: bold;
		animation: blink-animation 1.5s linear infinite;
		z-index:1;
	}
	@keyframes blink-animation {
		0% { opacity: 1; }
		50% { opacity: 0; }
		100% { opacity: 1; }
	}
</style>
</head>

<body>
<a id="aUrl" href="" target="_blank">
	<div class="container">
		<span class="live-text">LIVE</span>
		<video id="videoUrl" src="" width="300" height="250" loop playsinline autoplay muted></video>
		<div class="headline">Jerk Off With Someone Naked</div>
		<div class="cta">Jerk Off</div>
	</div>
</a>
	

<script>

	var url = "https://www.securegfm2.com/ae3efa9a-6b69-4fb0-8187-ab68b39a1df1?SID=us-b-t&SID2=us-Pornhub PC - Top Right Square&SID3=300x250-test4-camm159&SID4=test8-h2b&SID5=live-sign&kw=phskin&id=lj&ACLID={ACLID}";
	var url2 = "https://www.securegfm2.com/impression/ae3efa9a-6b69-4fb0-8187-ab68b39a1df1?SID=us-b-t&SID2=us-Pornhub PC - Top Right Square&SID3=300x250-test4-camm159&SID4=test8-h2b&SID5=live-sign&kw=phskin&id=lj&ACLID={ACLID}";
	
	document.getElementById("videoUrl").setAttribute("src", "https://dg-videos.b-cdn.net/bg/300x250_camm_159.mp4");
	document.getElementById("aUrl").setAttribute("href", url);
	
	var vli = new Image();
	vli.src = url2;
	
</script>


</body>
</html>